
"""
ela_forensics.py

Error Level Analysis (ELA) — image tampering/forgery detect
karne ki technique.

Requires:
    pip install Pillow numpy
"""

from PIL import Image, ImageChops, ImageEnhance
import numpy as np
import os
import tempfile


def error_level_analysis(image_path, quality=90, save_path=None):
    """
    ELA analysis perform karta hai.

    Returns:
        (ela_image, tamper_score)

    tamper_score jitna zyada hoga,
    tampering ka chance utna zyada maana jayega.
    """

    if not os.path.exists(image_path):
        raise FileNotFoundError(
            f"Image file nahi mili: {image_path}"
        )

    # Original image open karo
    original = Image.open(image_path).convert("RGB")

    # Temporary JPEG file create karo
    temp_fd, temp_path = tempfile.mkstemp(suffix=".jpg")
    os.close(temp_fd)

    try:
        # Image ko JPEG quality ke saath dobara save karo
        original.save(
            temp_path,
            "JPEG",
            quality=quality
        )

        # Re-saved image open karo
        resaved = Image.open(temp_path).convert("RGB")

        # Original aur re-saved image ka difference
        diff = ImageChops.difference(
            original,
            resaved
        )

        # Maximum difference calculate karo
        extrema = diff.getextrema()

        max_diff = max(
            ex[1]
            for ex in extrema
        )

        if max_diff == 0:
            max_diff = 1

        # Difference ko visible banane ke liye scale
        scale = 255.0 / max_diff

        ela_image = ImageEnhance.Brightness(
            diff
        ).enhance(scale)

        # Difference image ko numpy array mein convert karo
        diff_array = np.array(
            diff
        ).astype(float)

        # Tamper score
        tamper_score = float(
            np.std(diff_array)
        )

        # Agar save path diya gaya hai
        if save_path:
            ela_image.save(save_path)

        return ela_image, tamper_score

    finally:
        # Temporary file delete
        if os.path.exists(temp_path):
            os.remove(temp_path)


def is_likely_tampered(image_path, threshold=15.0):
    """
    Image tampering ka simple decision karta hai.

    threshold:
        Score is value se zyada hone par
        image ko potentially tampered maana jayega.

    NOTE:
        Real project mein threshold ko genuine/fake
        certificate dataset par calibrate karna chahiye.
    """

    _, score = error_level_analysis(
        image_path
    )

    return {
        "tamper_score": round(score, 2),
        "likely_tampered": score > threshold,
        "threshold_used": threshold,
    }


if __name__ == "__main__":
    import sys

    # Image path diya gaya hai ya nahi
    if len(sys.argv) < 2:
        print(
            "Usage: python ela_forensics.py <image_path>"
        )
        print(
            "Example: python ela_forensics.py sample.jpg"
        )
        sys.exit(1)

    image_path = sys.argv[1]

    try:
        result = is_likely_tampered(
            image_path
        )

        print("\nELA FORENSICS RESULT")
        print("--------------------")
        print(result)

    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)
