# utils/ocr_utils.py
import cv2
import pytesseract
import pdfplumber

def extract_text(file_path):
    if file_path.endswith(".pdf"):
        with pdfplumber.open(file_path) as pdf:
            first_page = pdf.pages[0]
            return first_page.extract_text()
    else:
        img = cv2.imread(file_path)
        return pytesseract.image_to_string(img)
