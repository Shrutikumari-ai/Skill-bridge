from flask import Flask, request, jsonify, render_template
import os

from ocr_extract import extract_fields
from ela_forensics import is_likely_tampered
from db_verify import verify_against_db, init_db


app = Flask(__name__)

# Uploaded certificates yahan save honge
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


def run_full_verification(image_path):
    """
    Certificate par 3 checks chalata hai:
    1. OCR
    2. ELA Forensics
    3. Database Verification
    """

    # 1. OCR
    fields = extract_fields(image_path)

    # 2. ELA / Tampering check
    forensics = is_likely_tampered(image_path)

    # 3. Database verification
    db_check = verify_against_db(fields)

    # Final decision
    is_genuine = (
        db_check.get("match", False)
        and not forensics.get("likely_tampered", False)
    )

    if is_genuine:
        verdict = "GENUINE"
    else:
        verdict = "SUSPECTED_FRAUD"

    return {
        "verdict": verdict,
        "extracted_fields": fields,
        "forensics_check": forensics,
        "database_check": db_check,
    }


# -----------------------------
# HOME PAGE
# -----------------------------

@app.route("/")
def home():
    return render_template("index.html")


# -----------------------------
# CERTIFICATE VERIFICATION API
# -----------------------------

@app.route("/verify-certificate", methods=["POST"])
def verify_certificate():

    # Check whether certificate file was uploaded
    if "certificate" not in request.files:
        return jsonify({
            "error": "No certificate file uploaded."
        }), 400

    file = request.files["certificate"]

    # Check empty file
    if file.filename == "":
        return jsonify({
            "error": "Please select a certificate image."
        }), 400

    # Allowed file types
    allowed_extensions = {
        ".jpg",
        ".jpeg",
        ".png"
    }

    filename = os.path.basename(file.filename)
    extension = os.path.splitext(filename)[1].lower()

    if extension not in allowed_extensions:
        return jsonify({
            "error": "Only JPG, JPEG and PNG certificate images are supported."
        }), 400

    # Save uploaded certificate
    save_path = os.path.join(
        UPLOAD_DIR,
        filename
    )

    file.save(save_path)

    try:
        # Run complete verification
        result = run_full_verification(save_path)

        return jsonify(result)

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# -----------------------------
# START FLASK SERVER
# -----------------------------

if __name__ == "__main__":

    # Database initialize
    init_db()

    # Start Flask
    app.run(
        debug=True,
        port=5000
    )
    

