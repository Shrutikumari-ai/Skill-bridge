"""
db_verify.py
Extracted certificate fields ko authorized database (university/govt records)
ke saath match karta hai. Yahan SQLite demo hai — real project me isse
apne existing SIS database (MySQL/PostgreSQL) se connect kar sakti ho.
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "certificates.db")


def init_db():
    """Demo ke liye ek sample verified-records table banata hai."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS verified_certificates (
            certificate_no TEXT PRIMARY KEY,
            student_name TEXT,
            university TEXT,
            degree TEXT,
            year TEXT
        )
    """)
    conn.commit()
    conn.close()


def add_verified_record(certificate_no, student_name, university, degree, year):
    """University/admin side se genuine records yahan add honge (bulk import)."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        INSERT OR REPLACE INTO verified_certificates
        (certificate_no, student_name, university, degree, year)
        VALUES (?, ?, ?, ?, ?)
    """, (certificate_no, student_name, university, degree, year))
    conn.commit()
    conn.close()


def verify_against_db(extracted_fields):
    """
    extracted_fields = ocr_extract.extract_fields() ka output.
    Return: match status + confidence
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cert_no = extracted_fields.get("certificate_no")
    if not cert_no:
        conn.close()
        return {"status": "NO_CERT_NUMBER_FOUND", "match": False}

    cur.execute("SELECT student_name, university, year FROM verified_certificates WHERE certificate_no=?", (cert_no,))
    row = cur.fetchone()
    conn.close()

    if row is None:
        return {"status": "NOT_FOUND_IN_RECORDS", "match": False}

    db_name, db_university, db_year = row
    name_match = (extracted_fields.get("name") or "").strip().lower() == db_name.strip().lower()
    univ_match = db_university.lower() in (extracted_fields.get("university") or "").lower()
    year_match = extracted_fields.get("year") == db_year

    score = sum([name_match, univ_match, year_match]) / 3.0

    return {
        "status": "FOUND",
        "match": score >= 0.66,
        "confidence": round(score, 2),
        "db_record": {"name": db_name, "university": db_university, "year": db_year},
    }


if __name__ == "__main__":
    init_db()
    # Sample genuine record daalne ka example:
    add_verified_record("CERT12345", "Anjali Sharma", "XYZ University", "BCA", "2025")
    print("DB ready with sample record.")
    