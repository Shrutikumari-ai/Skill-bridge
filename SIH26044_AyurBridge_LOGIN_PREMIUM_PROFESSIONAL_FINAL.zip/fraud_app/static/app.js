const form = document.getElementById("verifyForm");
const input = document.getElementById("certificate");
const dropzone = document.getElementById("dropzone");
const selectedFile = document.getElementById("selectedFile");
const selectedName = document.getElementById("selectedName");
const selectedSize = document.getElementById("selectedSize");
const removeFile = document.getElementById("removeFile");
const verifyBtn = document.getElementById("verifyBtn");
const btnText = document.getElementById("btnText");
const spinner = document.getElementById("spinner");
const message = document.getElementById("message");
const resultSection = document.getElementById("resultSection");

function showFile(file) {
    if (!file) return;

    const allowed = ["image/jpeg", "image/png"];
    if (!allowed.includes(file.type)) {
        showError("Please upload a JPG, JPEG or PNG image.");
        input.value = "";
        return;
    }

    selectedName.textContent = file.name;
    selectedSize.textContent = `${(file.size / 1024).toFixed(1)} KB`;
    selectedFile.style.display = "flex";
    document.getElementById("fileTitle").textContent = "Certificate selected";
    document.getElementById("fileHint").textContent = "Click here to choose another image";
    hideError();
}

input.addEventListener("change", () => showFile(input.files[0]));

["dragenter", "dragover"].forEach(eventName => {
    dropzone.addEventListener(eventName, e => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });
});

["dragleave", "drop"].forEach(eventName => {
    dropzone.addEventListener(eventName, e => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
    });
});

dropzone.addEventListener("drop", e => {
    const file = e.dataTransfer.files[0];
    if (file) {
        const dt = new DataTransfer();
        dt.items.add(file);
        input.files = dt.files;
        showFile(file);
    }
});

removeFile.addEventListener("click", () => {
    input.value = "";
    selectedFile.style.display = "none";
    document.getElementById("fileTitle").textContent = "Drop your certificate here";
    document.getElementById("fileHint").textContent = "or click to browse from your computer";
});

form.addEventListener("submit", async e => {
    e.preventDefault();

    if (!input.files[0]) {
        showError("Please select a certificate image first.");
        return;
    }

    const formData = new FormData();
    formData.append("certificate", input.files[0]);

    verifyBtn.disabled = true;
    btnText.textContent = "Verifying...";
    spinner.classList.remove("hidden");
    hideError();
    resultSection.classList.add("hidden");

    try {
        const response = await fetch("/verify-certificate", {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (!response.ok || data.error) {
            throw new Error(data.error || "Verification failed.");
        }

        renderResult(data);
    } catch (error) {
        showError(error.message);
    } finally {
        verifyBtn.disabled = false;
        btnText.textContent = "Verify Certificate";
        spinner.classList.add("hidden");
    }
});

function renderResult(data) {
    resultSection.classList.remove("hidden");

    const genuine = data.verdict === "GENUINE";
    const banner = document.getElementById("verdictBanner");
    const icon = document.getElementById("verdictIcon");

    banner.classList.toggle("danger", !genuine);
    icon.textContent = genuine ? "✓" : "!";

    document.getElementById("verdictText").textContent =
        genuine ? "GENUINE CERTIFICATE" : "SUSPECTED FRAUD";

    const fields = data.extracted_fields || {};
    const fieldContainer = document.getElementById("fields");
    const labels = {
        certificate_no: "Certificate No.",
        name: "Student Name",
        university: "University",
        year: "Year"
    };

    fieldContainer.innerHTML = Object.entries(labels).map(([key, label]) => `
        <div class="field">
            <span>${label}</span>
            <strong>${escapeHtml(fields[key] ?? "Not detected")}</strong>
        </div>
    `).join("");

    const forensic = data.forensics_check || {};
    document.getElementById("tamperScore").textContent =
        forensic.tamper_score ?? "—";
    document.getElementById("threshold").textContent =
        forensic.threshold_used ?? "—";

    const tamperBadge = document.getElementById("tamperBadge");
    const tampered = forensic.likely_tampered;
    tamperBadge.textContent = tampered ? "Potential tampering" : "No tampering flagged";
    tamperBadge.classList.toggle("danger", !!tampered);

    const db = data.database_check || {};
    document.getElementById("dbStatus").textContent =
        db.status || "No database result";

    document.getElementById("confidence").textContent =
        db.confidence !== undefined ? `${Math.round(db.confidence * 100)}%` : "—";

    const record = db.db_record;
    document.getElementById("dbRecord").innerHTML = record
        ? `<strong>Authorized record</strong><br>
           Name: ${escapeHtml(record.name || "—")}<br>
           University: ${escapeHtml(record.university || "—")}<br>
           Year: ${escapeHtml(record.year || "—")}`
        : "No matching authorized record found.";

    resultSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function showError(text) {
    message.textContent = text;
    message.classList.remove("hidden");
}

function hideError() {
    message.classList.add("hidden");
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
