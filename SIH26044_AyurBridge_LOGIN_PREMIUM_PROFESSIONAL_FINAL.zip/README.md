# SKILLBRIDGE Ayurveda — Integrated SIH Platform

This ZIP combines the Student Dashboard with:
1. Institute / Academia Dashboard
2. Industry Dashboard
3. Certificate Fraud / Document Verification

## Run

Windows PowerShell:

```powershell
cd "...\SKILLBRIDGE_AYURVEDA_INTEGRATED"
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Then open:

- Student: http://127.0.0.1:5000/
- Institute: http://127.0.0.1:5000/institute/dashboard
- Industry: http://127.0.0.1:5000/industry/
- Fraud Detection: http://127.0.0.1:5000/fraud/

The Student Dashboard contains direct cards for all three integrated modules.

## Notes

- Student + Institute share the same SQLAlchemy database/model layer.
- Industry remains isolated as a mounted Flask application so its existing features are preserved.
- Fraud Detection remains isolated as a mounted Flask application so its OCR/ELA/database verification workflow is preserved.
- The server uses one localhost port (5000).
