from datetime import date
from models import (
    db, Student, Internship, Company, Organization, Placement, AssessmentQuestion,
    AssessmentAttempt, AssessmentAnswer, LearningProgress, Application,
    IndustrySkillDemand, SkillGapRecord, LearningRecommendation, InternshipProgress,
    MentorFeedback, InternshipCompletion, StudentPortfolio, PortfolioVerification,
    PlacementReadiness, SkillMatch, CareerGuidance, IndustryWorkshop, GuestLecture,
    LiveIndustryProject, ResearchCollaboration, SecureDocument, RolePermission,
    IndustryJob, JobApplication, FacultyProgram, IndustryTraining,
    TrainingParticipation, Notification, InnovationChallenge, ChallengeSubmission,
)

AYURVEDA_SKILLS = [
    "Panchakarma", "Kayachikitsa", "Dravyaguna", "Rasashastra", "Bhaishajya Kalpana",
    "Shalya Tantra", "Shalakya Tantra", "Prasuti & Stri Roga", "Swasthavritta",
    "Agada Tantra", "Roga Nidana", "Ayurvedic Formulation", "Herbal Medicine",
    "Medicinal Plant Identification", "Clinical Research", "Pharmacovigilance",
    "Patient Counselling", "Clinical Documentation", "Ayurvedic Diagnosis", "Research Methodology"
]

def seed_data():
    # ---------- students ----------
    if Student.query.count() == 0:
        data = [
            ("Ananya Sharma","Panchakarma"),("Riya Verma","Kayachikitsa"),("Kavya Singh","Dravyaguna"),
            ("Mehak Gupta","Rasashastra"),("Pooja Yadav","Shalya Tantra"),("Sneha Kumari","Shalakya Tantra"),
            ("Aditi Chauhan","Prasuti & Stri Roga"),("Nandini Joshi","Swasthavritta"),("Ishita Mehta","Panchakarma"),
            ("Priya Saini","Kayachikitsa"),("Muskan Rani","Dravyaguna"),("Neha Thakur","Rasashastra")]
        year_map = [1,2,3,4,5,2,3,2,4,1,3,4]
        degree_map = ["BAMS","BAMS","BAMS","BAMS","BAMS","BHMS","BHMS","B.Pharm (Ayurveda)","B.Pharm (Ayurveda)","B.Sc Ayurveda","B.Sc Ayurveda","BAMS"]
        for i,(name,spec) in enumerate(data):
            skills = ", ".join([spec,"Patient Counselling","Clinical Documentation"])
            db.session.add(Student(name=name,status="Active",degree=degree_map[i],certificates="First Aid; Ayurveda Foundation",college="Ayurveda Institute",year=year_map[i],experience="Clinical rotation",specialization=spec,desired_field="Ayurveda Healthcare",skills=skills,city=["Panipat","Rohtak","Gurugram","Delhi"][i%4],state="Haryana" if i%3 else "Delhi"))
        db.session.commit()

    # Keep the bundled demo student records varied even when an older database
    # already exists from a previous ZIP. Only the known demo names are touched.
    demo_profiles = {
        "Ananya Sharma": ("BAMS", 1), "Riya Verma": ("BAMS", 2),
        "Kavya Singh": ("BAMS", 3), "Mehak Gupta": ("BAMS", 4),
        "Pooja Yadav": ("BAMS", 5), "Sneha Kumari": ("BHMS", 2),
        "Aditi Chauhan": ("BHMS", 3), "Nandini Joshi": ("B.Pharm (Ayurveda)", 2),
        "Ishita Mehta": ("B.Pharm (Ayurveda)", 4), "Priya Saini": ("B.Sc Ayurveda", 1),
        "Muskan Rani": ("B.Sc Ayurveda", 3), "Neha Thakur": ("BAMS", 4),
    }
    for student in Student.query.all():
        if student.name in demo_profiles:
            student.degree, student.year = demo_profiles[student.name]
    db.session.commit()

    students=Student.query.order_by(Student.id).all()

    # ---------- companies/orgs ----------
    if Company.query.count()==0:
        db.session.add_all([Company(name="National Ayurveda Institute",collab_type="Government",city="New Delhi",state="Delhi"),Company(name="Herbal Wellness Pvt Ltd",collab_type="Private",city="Gurugram",state="Haryana"),Company(name="NewLeaf Ayurvedics",collab_type="Industry",city="Rohtak",state="Haryana"),Company(name="AyurVeda Care Hospital",collab_type="Hospital",city="Gurugram",state="Haryana"),Company(name="Herbal Pharma R&D",collab_type="Pharma",city="Haridwar",state="Uttarakhand")])
    if Organization.query.count()==0:
        db.session.add_all([Organization(name="AIIMS Ayurveda Centre",sector="government",org_type="Hospital",city="New Delhi",state="Delhi"),Organization(name="State Ayurveda Hospital",sector="government",org_type="Ayurveda Hospital",city="Rohtak",state="Haryana"),Organization(name="Ayurvedic Relief Centre",sector="private",org_type="Healthcare Organization",city="Gurugram",state="Haryana")])
    db.session.commit()

    # ---------- internships ----------
    if Internship.query.count()==0:
        vals=[
        ("Panchakarma Clinical Internship","Clinical Ayurveda","government","BAMS","Panchakarma,Patient Care,Communication","Rohtak","Haryana","3 Months"),
        ("Ayurvedic Hospital Internship","Ayurveda Hospital","government","BAMS","Ayurvedic Diagnosis,Patient Care,Clinical Documentation","Hisar","Haryana","3 Months"),
        ("Ayurvedic Pharmaceutical Internship","Pharmacy & Formulation","private","BAMS","Ayurvedic Formulation,Rasashastra,Quality Control","Gurugram","Haryana","4 Months"),
        ("Herbal Medicine R&D Internship","Research & Development","private","BAMS","Herbal Medicine,Medicinal Plant Identification,Clinical Research","New Delhi","Delhi","6 Months"),
        ("Public Health Ayurveda Internship","Public Health","government","BAMS","Swasthavritta,Communication,Community Outreach","Jaipur","Rajasthan","3 Months"),
        ("Clinical Research Internship","Clinical Research","private","BAMS","Clinical Research,Research Methodology,Pharmacovigilance","Noida","Uttar Pradesh","6 Months"),
        ("Wellness & Patient Counselling Internship","Wellness","private","BAMS","Patient Counselling,Swasthavritta,Communication","Gurugram","Haryana","2 Months"),
        ("Ayurvedic Formulation Internship","Formulation","private","BAMS","Bhaishajya Kalpana,Rasashastra,Quality Control","Haridwar","Uttarakhand","4 Months")]
        for f,d,s,deg,skills,city,state,dur in vals: db.session.add(Internship(field=f,department=d,sector=s,required_degree=deg,required_skills=skills,city=city,state=state,duration=dur,description=f"Hands-on Ayurveda learning in {d}.",apply_link="#"))
        db.session.commit()
    internships=Internship.query.order_by(Internship.id).all()

    # ---------- assessment questions ----------
    if AssessmentQuestion.query.count()==0:
        qs=[
        ("Which therapy is a core Panchakarma procedure?","Vamana","MRI","Dialysis","Radiotherapy","A","Clinical Ayurveda"),
        ("Dravyaguna primarily deals with?","Medicinal properties of drugs","Hospital finance","Radiology","Surgery billing","A","Dravyaguna"),
        ("Rasashastra focuses on?","Herbo-mineral preparations","Physiotherapy","Radiology","Nutrition labels","A","Rasashastra"),
        ("Bhaishajya Kalpana relates to?","Drug preparation","Patient admission","Yoga posture","Hospital architecture","A","Formulation"),
        ("Swasthavritta emphasizes?","Preventive health and lifestyle","Only surgery","Only pharmacy","Only diagnostics","A","Swasthavritta"),
        ("Pharmacovigilance means monitoring?","Medicine safety","Building safety","Attendance","Transport","A","Pharmacovigilance"),
        ("A case record should primarily contain?","Accurate clinical documentation","Only patient name","Only billing","Only address","A","Documentation"),
        ("Patient counselling should be?","Clear and empathetic","Technical and confusing","Avoided","Unstructured","A","Communication"),
        ("Medicinal plant identification requires?","Correct botanical and medicinal identification","Guessing","Marketing only","Billing","A","Herbal Medicine"),
        ("Clinical research should follow?","Ethical and systematic methodology","Random claims","No records","Unverified results","A","Research"),
        ("Roga Nidana concerns?","Diagnosis and disease understanding","Accounts","Marketing","Architecture","A","Diagnosis"),
        ("Kayachikitsa primarily covers?","Internal medicine","Eye surgery only","Dentistry only","Accounting","A","Kayachikitsa"),
        ("Shalya Tantra is associated with?","Surgical procedures","Pharmacy billing","Yoga only","Nutrition only","A","Shalya Tantra"),
        ("Shalakya Tantra covers?","ENT and eye-related care","Accounts","Herbal farming","HR","A","Shalakya Tantra"),
        ("Prasuti & Stri Roga relates to?","Women’s health and obstetrics","Radiology","IT","Finance","A","Prasuti"),
        ("Agada Tantra is related to?","Toxicology","Accounting","Marketing","Architecture","A","Agada Tantra"),
        ("Quality control in Ayurvedic pharma ensures?","Consistent quality and safety","Faster billing","More advertisements","Attendance","A","Quality Control"),
        ("A good clinical note should be?","Accurate, timely and structured","Incomplete","Copied blindly","Anonymous","A","Documentation"),
        ("Evidence-based Ayurveda benefits from?","Clinical evidence and research","Rumours","Unrecorded cases","Advertising alone","A","Research"),
        ("Professional communication requires?","Active listening and clarity","Ignoring patients","Unclear language","No feedback","A","Communication"),
        ("Panchakarma planning should consider?","Patient assessment and suitability","Only age","Only location","Only billing","A","Panchakarma"),
        ("Herbal medicine development needs?","Identification, formulation and quality checks","Only packaging","Only promotion","Only sales","A","Herbal Medicine"),
        ("Research methodology helps with?","Reliable study design and analysis","Decoration","Attendance","Travel","A","Research"),
        ("Patient confidentiality means?","Protecting personal health information","Publishing everything","Sharing passwords","Ignoring consent","A","Professional Ethics"),
        ("Clinical documentation supports?","Continuity and safe patient care","Only advertising","Only payroll","Only transport","A","Documentation")]
        for q,a,b,c,d,correct,cat in qs: db.session.add(AssessmentQuestion(question=q,option_a=a,option_b=b,option_c=c,option_d=d,correct_answer=correct,category=cat,difficulty="medium",career_field="Ayurveda",degree="BAMS"))
        db.session.commit()

    # ---------- assessment attempts / learning ----------
    if AssessmentAttempt.query.count()==0:
        questions=AssessmentQuestion.query.filter(AssessmentQuestion.career_field=="Ayurveda").all()
        for i,s in enumerate(students[:6]):
            score=[82,76,68,61,55,88][i]; attempt=AssessmentAttempt(student_id=s.id,total_questions=25,correct_answers=round(score/4),score_percentage=score,technical_score=max(0,score-2),domain_score=score+3 if score<=96 else 96,problem_solving_score=max(0,score-5),aptitude_score=max(0,score-4),communication_score=min(100,score+5),soft_skills_score=min(100,score+7),status="completed")
            db.session.add(attempt); db.session.flush()
            for q in questions[:5]: db.session.add(AssessmentAnswer(attempt_id=attempt.id,question_id=q.id,selected_answer="A",is_correct=True))
    if LearningProgress.query.count()==0:
        for i,s in enumerate(students[:8]): db.session.add(LearningProgress(student_id=s.id,skill=["Panchakarma","Clinical Documentation","Patient Counselling","Ayurvedic Formulation"][i%4],progress=[80,65,70,90][i%4],completed=i<4))
    db.session.commit()

    # ---------- applications / placements ----------
    if Application.query.count()==0:
        for i in range(6): db.session.add(Application(student_id=students[i].id,internship_id=internships[i%len(internships)].id,status=["Applied","Shortlisted","Selected","Applied","Shortlisted","Completed"][i],cover_note="Interested in Ayurveda-domain clinical learning."))
    if Placement.query.count()==0:
        companies=Company.query.order_by(Company.id).all()
        for i in range(3): db.session.add(Placement(student_id=students[i].id,company_id=companies[i].id,internship_id=internships[i].id,status="placed"))
    db.session.commit()

    # ---------- skill demand ----------
    if IndustrySkillDemand.query.count()==0:
        demands=[("Panchakarma","Clinical","High",120,12),("Ayurvedic Formulation","Pharma","High",180,18),("Clinical Research","Research","High",140,14),("Patient Care","Clinical","High",160,16),("Clinical Documentation","Clinical","Medium",90,9),("Pharmacovigilance","Research","High",110,14),("Patient Counselling","Wellness","Medium",100,11),("Quality Control","Pharma","Medium",85,10),("Public Health Ayurveda","Public Health","Medium",70,8),("Medicinal Plant Identification","Research","High",105,13)]
        for skill,domain,level,req,ind in demands: db.session.add(IndustrySkillDemand(skill=skill,domain=domain,demand_level=level,required_count=req,industry_count=ind,description=f"Current Ayurveda industry demand for {skill}."))
    if SkillGapRecord.query.count()==0:
        for i,s in enumerate(students): db.session.add(SkillGapRecord(student_id=s.id,target_role="Ayurvedic Clinical Officer",required_skills="Panchakarma,Patient Care,Clinical Documentation,Communication",current_skills=s.skills,missing_skills="Clinical Documentation,Patient Counselling" if i%2==0 else "Panchakarma",gap_percentage=24 if i%2==0 else 18,readiness_percentage=76 if i%2==0 else 82))
    if LearningRecommendation.query.count()==0:
        for i,s in enumerate(students[:8]): db.session.add(LearningRecommendation(student_id=s.id,skill="Clinical Documentation",recommendation_type="Workshop",title="Clinical Documentation Workshop",roadmap="Assessment → Workshop → Mentor Session → Hospital Internship → Re-assessment",status="Recommended",reassessment_score=78 if i<2 else None))
    db.session.commit()

    # ---------- internship workflow ----------
    if InternshipProgress.query.count()==0:
        stages=["Applied","Shortlisted","Selected","Started","In Progress","Completed"]
        for i,s in enumerate(students[:6]): db.session.add(InternshipProgress(student_id=s.id,internship_id=internships[i].id,status=stages[i],progress_percentage=[10,25,40,55,75,100][i],milestones="Orientation → Clinical task → Mentor review → Final evaluation",tasks="Case documentation, patient counselling and supervised clinical practice"))
    if MentorFeedback.query.count()==0:
        for i,s in enumerate(students[:5]): db.session.add(MentorFeedback(student_id=s.id,internship_id=internships[i].id,mentor_name=["Dr. Kavita Rao","Dr. Amit Joshi","Dr. Meena Kapoor"][i%3],mentor_organization="Ayurveda Clinical Centre",clinical_skill=80+i,patient_handling=78+i,ayurveda_knowledge=85,communication=82,professional_behaviour=86,overall_rating=4.2,comments="Good clinical discipline and Ayurveda knowledge."))
    if InternshipCompletion.query.count()==0:
        db.session.add(InternshipCompletion(student_id=students[5].id,internship_id=internships[5].id,completion_status="Completed",duration="6 Months",mentor="Dr. Kavita Rao",skills_acquired="Clinical Research,Clinical Documentation,Patient Counselling",final_rating=4.6,certificate="Ayurveda Clinical Research Internship Certificate"))
    db.session.commit()

    # ---------- portfolio/readiness/matching ----------
    if StudentPortfolio.query.count()==0:
        for s in students:
            db.session.add(StudentPortfolio(student_id=s.id,verified_skills=s.skills,certifications="Panchakarma Foundation; First Aid",internships="Ayurvedic Hospital Clinical Internship",projects="Ayurveda Patient-Care Digital Workflow",achievements="Best Clinical Presentation",publications="Student Research Abstract – Ayurveda",career_profile=f"BAMS student targeting {s.specialization} and clinical Ayurveda roles.",verification_status="Verified",institute_verified=True))
    if PlacementReadiness.query.count()==0:
        for i,s in enumerate(students):
            scores=[82,78,74,69,65,88,72,81,67,76,71,79]; score=scores[i % len(scores)]; db.session.add(PlacementReadiness(student_id=s.id,target_role="Ayurvedic Clinical Officer",technical_score=max(0,score-2),domain_score=min(100,score+2),communication_score=min(100,score+4),soft_skill_score=min(100,score+3),internship_score=min(100,score+6),overall_readiness=score,readiness_label="Placement Ready" if score>=75 else "Developing",required_skills="BAMS,Panchakarma,Patient Care,Communication",current_skills=s.skills))
    if SkillMatch.query.count()==0:
        for i,s in enumerate(students[:8]): db.session.add(SkillMatch(student_id=s.id,job_role="Ayurvedic Clinical Officer",industry="Ayurvedic Hospital",match_percentage=87-i*3,matched_skills="Patient Care,Panchakarma,Communication",missing_skills="Clinical Documentation",recommended_improvement="Complete documentation workshop and re-assessment."))
    db.session.commit()

    # ---------- career / academia extended ----------
    if CareerGuidance.query.count()==0:
        for c,d,skills,profile,desc in [("Ayurvedic Clinical Officer","Clinical","Panchakarma,Patient Care,Communication","BAMS + clinical profile","Patient diagnosis, care and clinical practice."),("Panchakarma Therapist","Clinical","Panchakarma,Patient Counselling,Documentation","Panchakarma training","Specialized Panchakarma service delivery."),("Ayurvedic Formulation Specialist","Pharma","Ayurvedic Formulation,Rasashastra,Quality Control","Formulation interest","Drug formulation and quality operations."),("Clinical Research Associate","Research","Clinical Research,Research Methodology,Pharmacovigilance","Research profile","Evidence-based Ayurveda research."),("Wellness Consultant","Wellness","Patient Counselling,Swasthavritta,Communication","Wellness profile","Lifestyle and preventive wellness.")]: db.session.add(CareerGuidance(career=c,domain=d,required_skills=skills,suitable_profile=profile,description=desc))
    if IndustryWorkshop.query.count()==0: db.session.add_all([IndustryWorkshop(title="Panchakarma Clinical Skills Workshop",expert="Ayurveda Industry Expert",topic="Safe Panchakarma procedures",workshop_date=date(2026,9,15),participants=60,attendance=54,completion=48),IndustryWorkshop(title="Ayurvedic Formulation Workshop",expert="Pharma R&D Expert",topic="Formulation and quality control",workshop_date=date(2026,10,5),participants=80,attendance=72,completion=65)])
    if GuestLecture.query.count()==0: db.session.add_all([GuestLecture(expert="Senior Ayurveda Clinician",topic="Career opportunities in clinical Ayurveda",lecture_date=date(2026,9,20),participants=120,feedback_score=4.5),GuestLecture(expert="Ayurveda Pharma Expert",topic="From formulation to industry",lecture_date=date(2026,10,10),participants=100,feedback_score=4.4)])
    if LiveIndustryProject.query.count()==0: db.session.add_all([LiveIndustryProject(project_name="Ayurveda Patient-Care Digital Workflow",industry="Ayurvedic Hospital",assigned_students="BAMS Cohort A",mentor="Clinical Mentor",deadline=date(2026,11,15),progress=65,completion=40),LiveIndustryProject(project_name="Herbal Product Quality Dashboard",industry="Ayurvedic Pharma",assigned_students="Research Team",mentor="R&D Mentor",deadline=date(2026,12,1),progress=45,completion=20)])
    if ResearchCollaboration.query.count()==0: db.session.add(ResearchCollaboration(project_name="Evidence-based Panchakarma Outcomes",organization="Ayurveda Research Organization",faculty="Faculty Research Cell",students="BAMS Research Group",status="Active",outcomes="Patient outcome dataset and research manuscript in progress."))
    if RolePermission.query.count()==0:
        for role,vals in {"Student":(1,1,1,0,1,1),"Institute":(1,1,1,1,1,1),"Industry":(1,0,1,1,1,0),"Faculty/Academician":(1,1,1,0,1,1),"Admin":(1,1,1,1,1,1)}.items(): db.session.add(RolePermission(role=role,dashboard=vals[0],students=vals[1],internships=vals[2],placements=vals[3],analytics=vals[4],documents=vals[5]))
    db.session.commit()

    # ---------- industry jobs/recruitment ----------
    if IndustryJob.query.count()==0:
        jobs=[("Ayurvedic Clinical Officer","AyurVeda Care Hospital","BAMS","Panchakarma,Patient Care,Clinical Documentation","Gurugram, Haryana","₹4–6 LPA",date(2026,10,15)),("Ayurvedic Formulation Specialist","HerbalLife Ayurveda","BAMS / M.Pharm","Ayurvedic Formulation,Rasashastra,Quality Control","Haridwar, Uttarakhand","₹5–8 LPA",date(2026,11,5)),("Clinical Research Associate","Ayush Research Labs","BAMS","Clinical Research,Research Methodology,Pharmacovigilance","New Delhi","₹5–7 LPA",date(2026,10,28))]
        for x in jobs: db.session.add(IndustryJob(title=x[0],company=x[1],required_degree=x[2],required_skills=x[3],location=x[4],package=x[5],deadline=x[6],description="Ayurveda-domain industry opportunity."))
        db.session.commit()
    if JobApplication.query.count()==0:
        jobs=IndustryJob.query.order_by(IndustryJob.id).all(); statuses=["Applied","Shortlisted","Interview Scheduled","Selected","Rejected","Final Placement"]
        for i in range(6): db.session.add(JobApplication(student_id=students[i].id,job_id=jobs[i%3].id,status=statuses[i],interview_date=date(2026,9,25) if i==2 else None))
    if FacultyProgram.query.count()==0: db.session.add_all([FacultyProgram(faculty_name="Dr. Neha Sharma",program_type="Faculty Internship",organization="Ayurveda Wellness Hospital",topic="Panchakarma Clinical Workflow",start_date=date(2026,9,1),end_date=date(2026,9,30),status="Active",outcome="Clinical exposure and SOP review"),FacultyProgram(faculty_name="Dr. Rajiv Menon",program_type="FDP",organization="Ayurveda Research Centre",topic="Evidence-based Ayurveda Research",start_date=date(2026,10,1),end_date=date(2026,10,5),status="Planned",outcome="Research methodology upskilling"),FacultyProgram(faculty_name="Dr. Pooja Singh",program_type="Research Collaboration",organization="Herbal Medicine R&D Lab",topic="Medicinal Plant Validation",start_date=date(2026,9,15),end_date=date(2027,1,15),status="Active",outcome="Joint research protocol")])
    if IndustryTraining.query.count()==0:
        db.session.add_all([IndustryTraining(title="Panchakarma Skill Training",provider="Ayurveda Clinical Academy",skill="Panchakarma",duration="6 Weeks",certificate="Industry Certificate",mentor="Clinical Mentor",seats=40,progress=65),IndustryTraining(title="Ayurvedic Drug Formulation",provider="Herbal Pharma R&D",skill="Ayurvedic Formulation",duration="8 Weeks",certificate="Formulation Certificate",mentor="R&D Mentor",seats=35,progress=45),IndustryTraining(title="Pharmacovigilance for Ayurveda",provider="Ayush Safety Centre",skill="Pharmacovigilance",duration="4 Weeks",certificate="PV Certificate",mentor="Safety Expert",seats=50,progress=30)])
        db.session.commit()
    if TrainingParticipation.query.count()==0:
        trainings=IndustryTraining.query.order_by(IndustryTraining.id).all()
        for i,s in enumerate(students[:6]): db.session.add(TrainingParticipation(student_id=s.id,training_id=trainings[i%3].id,status="Completed" if i<2 else "In Progress",progress=100 if i<2 else 55,certificate_status="Issued" if i<2 else "Pending"))
    if Notification.query.count()==0:
        db.session.add_all([Notification(title="Application shortlisted",message="Ananya Sharma has been shortlisted for an Ayurveda industry interview.",category="Shortlisting",audience="Students",priority="High"),Notification(title="Internship milestone due",message="Panchakarma internship milestone review is due this week.",category="Internship",audience="Students"),Notification(title="Industry interview schedule",message="Clinical Research Associate interviews are scheduled for 25 September 2026.",category="Interview",audience="Institute",priority="High"),Notification(title="Placement confirmation",message="A selected student has moved to Final Placement stage.",category="Placement",audience="Institute",priority="High"),Notification(title="Training certificate available",message="Completed Panchakarma certificates are ready for verification.",category="Certification",audience="Students"),Notification(title="Challenge deadline reminder",message="Innovation challenge submissions close soon.",category="Deadline",audience="Students",priority="Urgent")])
    if InnovationChallenge.query.count()==0:
        db.session.add_all([InnovationChallenge(title="Smart Herbal Formulation Innovation Challenge",industry="Ayurvedic Pharma",problem_statement="Design a safe, scalable workflow for documenting and validating herbal formulations.",skills="Herbal Medicine,Ayurvedic Formulation,Quality Control",deadline=date(2026,10,30)),InnovationChallenge(title="Digital Panchakarma Patient Journey",industry="Ayurvedic Hospital",problem_statement="Improve patient education, treatment tracking and follow-up during Panchakarma.",skills="Panchakarma,Patient Counselling,Clinical Documentation",deadline=date(2026,11,20))])
        db.session.commit()
    if ChallengeSubmission.query.count()==0:
        challenges=InnovationChallenge.query.order_by(InnovationChallenge.id).all()
        for i,s in enumerate(students[:4]): db.session.add(ChallengeSubmission(challenge_id=challenges[i%2].id,student_id=s.id,team_name=f"Ayurveda Innovators {i+1}",submission="Prototype workflow and evaluation plan",score=82-i*3,result="Winner" if i==0 else "Evaluated"))
    db.session.commit()

    print("="*40)
    print("Ayurveda SkillBridge seed completed.")
    print("Students:", Student.query.count())
    print("Internships:", Internship.query.count())
    print("Industry Jobs:", IndustryJob.query.count())
    print("Job Applications:", JobApplication.query.count())
    print("Skill Demands:", IndustrySkillDemand.query.count())
    print("Industry Trainings:", IndustryTraining.query.count())
    print("Faculty Programs:", FacultyProgram.query.count())
    print("Notifications:", Notification.query.count())
    print("Innovation Challenges:", InnovationChallenge.query.count())
    print("="*40)
