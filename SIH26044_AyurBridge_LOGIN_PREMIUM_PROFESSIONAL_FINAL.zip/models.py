from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


# ==========================================
# STUDENT
# ==========================================

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(20), nullable=False)

    degree = db.Column(db.String(80))
    certificates = db.Column(db.String(300))
    college = db.Column(db.String(150))
    year = db.Column(db.Integer)
    experience = db.Column(db.String(300))
    specialization = db.Column(db.String(150))
    desired_field = db.Column(db.String(150))
    skills = db.Column(db.String(500))

    # NEW: Student location
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))

    def skill_list(self):
        return [
            s.strip().lower()
            for s in (self.skills or "").split(",")
            if s.strip()
        ]


# ==========================================
# INTERNSHIP / OPPORTUNITY
# ==========================================

class Internship(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    field = db.Column(db.String(150), nullable=False)
    department = db.Column(db.String(150))

    # government / private
    sector = db.Column(db.String(20))

    required_degree = db.Column(db.String(80))
    required_skills = db.Column(db.String(500))

    # NEW: Opportunity location
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))

    # NEW: Duration
    duration = db.Column(db.String(100))

    # NEW: Opportunity description
    description = db.Column(db.Text)

    # NEW: Apply/details link
    apply_link = db.Column(db.String(500))

    def required_skill_list(self):
        return [
            s.strip().lower()
            for s in (self.required_skills or "").split(",")
            if s.strip()
        ]


# ==========================================
# ORGANIZATION
# ==========================================

class Organization(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(150), nullable=False)
    sector = db.Column(db.String(20))
    org_type = db.Column(db.String(50))

    city = db.Column(db.String(100))
    state = db.Column(db.String(100))


# ==========================================
# COMPANY
# ==========================================

class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(150), nullable=False)
    collab_type = db.Column(db.String(30))

    city = db.Column(db.String(100))
    state = db.Column(db.String(100))


# ==========================================
# PLACEMENT
# ==========================================

class Placement(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    student_id = db.Column(
        db.Integer,
        db.ForeignKey("student.id"),
        nullable=False
    )

    company_id = db.Column(
        db.Integer,
        db.ForeignKey("company.id"),
        nullable=False
    )

    internship_id = db.Column(
        db.Integer,
        db.ForeignKey("internship.id"),
        nullable=True
    )

    status = db.Column(
        db.String(30),
        default="placed"
    )

    student = db.relationship("Student")
    company = db.relationship("Company")
    internship = db.relationship("Internship")


# ==========================================
# ASSESSMENT QUESTION
# ==========================================

class AssessmentQuestion(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    question = db.Column(db.Text, nullable=False)

    option_a = db.Column(db.String(500), nullable=False)
    option_b = db.Column(db.String(500), nullable=False)
    option_c = db.Column(db.String(500), nullable=False)
    option_d = db.Column(db.String(500), nullable=False)

    correct_answer = db.Column(db.String(1), nullable=False)

    category = db.Column(db.String(50), nullable=False)
    difficulty = db.Column(
        db.String(20),
        default="medium"
    )

    career_field = db.Column(db.String(100))
    degree = db.Column(db.String(100))

    def options(self):
        return {
            "A": self.option_a,
            "B": self.option_b,
            "C": self.option_c,
            "D": self.option_d
        }


# ==========================================
# ASSESSMENT ATTEMPT
# ==========================================

class AssessmentAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    student_id = db.Column(
        db.Integer,
        db.ForeignKey("student.id"),
        nullable=False
    )

    total_questions = db.Column(
        db.Integer,
        default=0
    )

    correct_answers = db.Column(
        db.Integer,
        default=0
    )

    score_percentage = db.Column(
        db.Float,
        default=0.0
    )

    technical_score = db.Column(
        db.Float,
        default=0.0
    )

    domain_score = db.Column(
        db.Float,
        default=0.0
    )

    problem_solving_score = db.Column(
        db.Float,
        default=0.0
    )

    aptitude_score = db.Column(
        db.Float,
        default=0.0
    )

    communication_score = db.Column(
        db.Float,
        default=0.0
    )

    soft_skills_score = db.Column(
        db.Float,
        default=0.0
    )

    status = db.Column(
        db.String(30),
        default="completed"
    )

    student = db.relationship(
        "Student",
        backref=db.backref(
            "assessment_attempts",
            lazy=True
        )
    )


# ==========================================
# ASSESSMENT ANSWER
# ==========================================

class AssessmentAnswer(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    attempt_id = db.Column(
        db.Integer,
        db.ForeignKey("assessment_attempt.id"),
        nullable=False
    )

    question_id = db.Column(
        db.Integer,
        db.ForeignKey("assessment_question.id"),
        nullable=False
    )

    selected_answer = db.Column(
        db.String(1)
    )

    is_correct = db.Column(
        db.Boolean,
        default=False
    )

    attempt = db.relationship(
        "AssessmentAttempt",
        backref=db.backref(
            "answers",
            lazy=True
        )
    )

    question = db.relationship(
        "AssessmentQuestion"
    )


# ==========================================
# LEARNING PROGRESS
# ==========================================

class LearningProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    student_id = db.Column(
        db.Integer,
        db.ForeignKey("student.id"),
        nullable=False
    )

    skill = db.Column(
        db.String(100),
        nullable=False
    )

    progress = db.Column(
        db.Float,
        default=0.0
    )

    completed = db.Column(
        db.Boolean,
        default=False
    )

    student = db.relationship(
        "Student",
        backref=db.backref(
            "learning_progress",
            lazy=True
        )
    )
    # ==========================================
# STUDENT APPLICATION
# ==========================================

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    student_id = db.Column(
        db.Integer,
        db.ForeignKey("student.id"),
        nullable=False
    )

    internship_id = db.Column(
        db.Integer,
        db.ForeignKey("internship.id"),
        nullable=False
    )

    status = db.Column(
        db.String(30),
        default="Applied"
    )

    applied_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    cover_note = db.Column(db.Text)

    student = db.relationship(
        "Student",
        backref=db.backref(
            "applications",
            lazy=True
        )
    )

    internship = db.relationship(
        "Internship",
        backref=db.backref(
            "applications",
            lazy=True
        )
    )

    __table_args__ = (
        db.UniqueConstraint(
            "student_id",
            "internship_id",
            name="unique_student_internship_application"
        ),
    )

# =========================================================
# SIH26044 ADVANCED INSTITUTE MODULES
# =========================================================

class IndustrySkillDemand(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    skill = db.Column(db.String(120), nullable=False)
    domain = db.Column(db.String(80), nullable=False)
    demand_level = db.Column(db.String(20), default="Medium")
    required_count = db.Column(db.Integer, default=0)
    industry_count = db.Column(db.Integer, default=0)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SkillGapRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    target_role = db.Column(db.String(150), nullable=False)
    required_skills = db.Column(db.Text)
    current_skills = db.Column(db.Text)
    missing_skills = db.Column(db.Text)
    gap_percentage = db.Column(db.Float, default=0)
    readiness_percentage = db.Column(db.Float, default=0)
    student = db.relationship("Student")


class LearningRecommendation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    skill = db.Column(db.String(120), nullable=False)
    recommendation_type = db.Column(db.String(50), default="Training")
    title = db.Column(db.String(180), nullable=False)
    roadmap = db.Column(db.Text)
    status = db.Column(db.String(30), default="Recommended")
    reassessment_score = db.Column(db.Float)
    student = db.relationship("Student")


class InternshipProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    internship_id = db.Column(db.Integer, db.ForeignKey("internship.id"), nullable=False)
    status = db.Column(db.String(30), default="Applied")
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    progress_percentage = db.Column(db.Float, default=0)
    milestones = db.Column(db.Text)
    tasks = db.Column(db.Text)
    student = db.relationship("Student")
    internship = db.relationship("Internship")


class MentorFeedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    internship_id = db.Column(db.Integer, db.ForeignKey("internship.id"))
    mentor_name = db.Column(db.String(150), nullable=False)
    mentor_organization = db.Column(db.String(150))
    clinical_skill = db.Column(db.Float, default=0)
    patient_handling = db.Column(db.Float, default=0)
    ayurveda_knowledge = db.Column(db.Float, default=0)
    communication = db.Column(db.Float, default=0)
    professional_behaviour = db.Column(db.Float, default=0)
    overall_rating = db.Column(db.Float, default=0)
    comments = db.Column(db.Text)
    student = db.relationship("Student")
    internship = db.relationship("Internship")


class InternshipCompletion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    internship_id = db.Column(db.Integer, db.ForeignKey("internship.id"), nullable=False)
    completion_status = db.Column(db.String(30), default="Completed")
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    duration = db.Column(db.String(80))
    mentor = db.Column(db.String(150))
    skills_acquired = db.Column(db.Text)
    final_rating = db.Column(db.Float, default=0)
    certificate = db.Column(db.String(300))
    student = db.relationship("Student")
    internship = db.relationship("Internship")


class StudentPortfolio(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    verified_skills = db.Column(db.Text)
    certifications = db.Column(db.Text)
    internships = db.Column(db.Text)
    projects = db.Column(db.Text)
    achievements = db.Column(db.Text)
    publications = db.Column(db.Text)
    career_profile = db.Column(db.Text)
    verification_status = db.Column(db.String(30), default="Pending")
    institute_verified = db.Column(db.Boolean, default=False)
    student = db.relationship("Student")


class PortfolioVerification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    portfolio_id = db.Column(db.Integer, db.ForeignKey("student_portfolio.id"), nullable=False)
    document_name = db.Column(db.String(180), nullable=False)
    document_type = db.Column(db.String(80))
    status = db.Column(db.String(30), default="Pending")
    verified_by = db.Column(db.String(150))
    remarks = db.Column(db.Text)
    portfolio = db.relationship("StudentPortfolio")


class PlacementReadiness(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    target_role = db.Column(db.String(150), nullable=False)
    technical_score = db.Column(db.Float, default=0)
    domain_score = db.Column(db.Float, default=0)
    communication_score = db.Column(db.Float, default=0)
    soft_skill_score = db.Column(db.Float, default=0)
    internship_score = db.Column(db.Float, default=0)
    overall_readiness = db.Column(db.Float, default=0)
    readiness_label = db.Column(db.String(40))
    required_skills = db.Column(db.Text)
    current_skills = db.Column(db.Text)
    student = db.relationship("Student")


class SkillMatch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    job_role = db.Column(db.String(150), nullable=False)
    industry = db.Column(db.String(150))
    match_percentage = db.Column(db.Float, default=0)
    matched_skills = db.Column(db.Text)
    missing_skills = db.Column(db.Text)
    recommended_improvement = db.Column(db.Text)
    student = db.relationship("Student")


class CareerGuidance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    career = db.Column(db.String(150), nullable=False)
    domain = db.Column(db.String(100))
    required_skills = db.Column(db.Text)
    suitable_profile = db.Column(db.Text)
    description = db.Column(db.Text)


class IndustryWorkshop(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    expert = db.Column(db.String(150))
    topic = db.Column(db.String(180))
    workshop_date = db.Column(db.Date)
    participants = db.Column(db.Integer, default=0)
    attendance = db.Column(db.Integer, default=0)
    completion = db.Column(db.Integer, default=0)


class GuestLecture(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    expert = db.Column(db.String(150), nullable=False)
    topic = db.Column(db.String(180))
    lecture_date = db.Column(db.Date)
    participants = db.Column(db.Integer, default=0)
    feedback_score = db.Column(db.Float, default=0)


class LiveIndustryProject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    project_name = db.Column(db.String(180), nullable=False)
    industry = db.Column(db.String(150))
    assigned_students = db.Column(db.String(300))
    mentor = db.Column(db.String(150))
    deadline = db.Column(db.Date)
    progress = db.Column(db.Integer, default=0)
    completion = db.Column(db.Integer, default=0)


class ResearchCollaboration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    project_name = db.Column(db.String(180), nullable=False)
    organization = db.Column(db.String(180))
    faculty = db.Column(db.String(300))
    students = db.Column(db.String(300))
    status = db.Column(db.String(50), default="Active")
    outcomes = db.Column(db.Text)


class SecureDocument(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    document_name = db.Column(db.String(180), nullable=False)
    document_type = db.Column(db.String(80))
    verification_status = db.Column(db.String(40), default="Pending Verification")
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    student = db.relationship("Student")


class RolePermission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.String(50), nullable=False, unique=True)
    dashboard = db.Column(db.Boolean, default=False)
    students = db.Column(db.Boolean, default=False)
    internships = db.Column(db.Boolean, default=False)
    placements = db.Column(db.Boolean, default=False)
    analytics = db.Column(db.Boolean, default=False)
    documents = db.Column(db.Boolean, default=False)


# =========================================================
# SIH26044 EXTENDED INSTITUTE ECOSYSTEM MODULES
# =========================================================

class IndustryJob(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    company = db.Column(db.String(180), nullable=False)
    required_degree = db.Column(db.String(100), default="BAMS")
    required_skills = db.Column(db.Text)
    location = db.Column(db.String(150))
    package = db.Column(db.String(100))
    deadline = db.Column(db.Date)
    description = db.Column(db.Text)
    status = db.Column(db.String(30), default="Open")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class JobApplication(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey("industry_job.id"), nullable=False)
    status = db.Column(db.String(40), default="Applied")
    interview_date = db.Column(db.Date)
    notes = db.Column(db.Text)
    applied_at = db.Column(db.DateTime, default=datetime.utcnow)
    student = db.relationship("Student")
    job = db.relationship("IndustryJob")

class FacultyProgram(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    faculty_name = db.Column(db.String(150), nullable=False)
    program_type = db.Column(db.String(80), nullable=False)
    organization = db.Column(db.String(180))
    topic = db.Column(db.String(200))
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    status = db.Column(db.String(40), default="Planned")
    outcome = db.Column(db.Text)

class IndustryTraining(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    provider = db.Column(db.String(180))
    skill = db.Column(db.String(120))
    duration = db.Column(db.String(80))
    certificate = db.Column(db.String(150))
    mentor = db.Column(db.String(150))
    seats = db.Column(db.Integer, default=0)
    progress = db.Column(db.Integer, default=0)
    status = db.Column(db.String(40), default="Open")

class TrainingParticipation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    training_id = db.Column(db.Integer, db.ForeignKey("industry_training.id"), nullable=False)
    status = db.Column(db.String(40), default="Enrolled")
    progress = db.Column(db.Integer, default=0)
    certificate_status = db.Column(db.String(40), default="Pending")
    student = db.relationship("Student")
    training = db.relationship("IndustryTraining")

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    message = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(60), default="General")
    audience = db.Column(db.String(60), default="Institute")
    priority = db.Column(db.String(20), default="Normal")
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class InnovationChallenge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    industry = db.Column(db.String(180))
    problem_statement = db.Column(db.Text)
    skills = db.Column(db.Text)
    deadline = db.Column(db.Date)
    status = db.Column(db.String(40), default="Open")

class ChallengeSubmission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    challenge_id = db.Column(db.Integer, db.ForeignKey("innovation_challenge.id"), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    team_name = db.Column(db.String(150))
    submission = db.Column(db.Text)
    score = db.Column(db.Float, default=0)
    result = db.Column(db.String(50), default="Under Evaluation")
    challenge = db.relationship("InnovationChallenge")
    student = db.relationship("Student")

class SecureDocumentFile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    document_name = db.Column(db.String(180), nullable=False)
    stored_name = db.Column(db.String(300), nullable=False, unique=True)
    document_type = db.Column(db.String(80))
    verification_status = db.Column(db.String(40), default="Pending Verification")
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    student = db.relationship("Student")
