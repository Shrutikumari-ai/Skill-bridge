from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, session
from werkzeug.utils import secure_filename
import hashlib, mimetypes
try:
    from fraud.ela_forensics import error_level_analysis
except Exception:
    error_level_analysis = None
try:
    from fraud.ocr_extract import extract_fields
except Exception:
    extract_fields = None
try:
    from fraud.db_verify import init_db as init_fraud_db, verify_against_db
except Exception:
    init_fraud_db = None
    verify_against_db = None
from pathlib import Path
from datetime import datetime
import os

app=Flask(__name__)
app.secret_key='sih26044-industry-demo-secret'
UPLOAD=Path(app.root_path)/'uploads'; UPLOAD.mkdir(exist_ok=True)

jobs=[
 {'id':1,'title':'Panchakarma Therapist','company':'AyurCare Wellness Centre','skills':'Panchakarma, Patient Care, Communication','location':'Delhi','salary':'₹4.5–6 LPA','deadline':'30 Sep 2026','status':'Open'},
 {'id':2,'title':'Ayurvedic Clinical Officer','company':'Dhanvantari Hospitals','skills':'Kayachikitsa, Ayurvedic Diagnosis, Documentation','location':'Gurugram','salary':'₹5–7 LPA','deadline':'05 Oct 2026','status':'Open'},
 {'id':3,'title':'Ayurvedic Formulation Associate','company':'HerbLife Research Labs','skills':'Rasashastra, Bhaishajya Kalpana, Quality Control','location':'Noida','salary':'₹4–6 LPA','deadline':'12 Oct 2026','status':'Open'},
]
applications=[
 {'id':1,'student':'Ananya Sharma','job':'Panchakarma Therapist','company':'AyurCare Wellness Centre','status':'Shortlisted'},
 {'id':2,'student':'Riya Verma','job':'Ayurvedic Clinical Officer','company':'Dhanvantari Hospitals','status':'Under Review'},
 {'id':3,'student':'Kavya Singh','job':'Ayurvedic Formulation Associate','company':'HerbLife Research Labs','status':'Selected'},
]
internships=[
 {'id':1,'student':'Ananya Sharma','title':'Panchakarma Clinical Internship','company':'AyurCare Wellness Centre','status':'In Progress','mentor':'Dr. Meera Joshi','duration':'8 weeks','skills':'Panchakarma, Patient Care, Documentation'},
 {'id':2,'student':'Riya Verma','title':'Ayurvedic Hospital Internship','company':'Dhanvantari Hospitals','status':'Completed','mentor':'Dr. Arjun Rao','duration':'6 weeks','skills':'Kayachikitsa, Diagnosis, Communication'},
 {'id':3,'student':'Kavya Singh','title':'Herbal Medicine R&D Internship','company':'HerbLife Research Labs','status':'Shortlisted','mentor':'Dr. Nitin Sharma','duration':'10 weeks','skills':'Dravyaguna, Research Methodology'},
]
skill_demand=[
 {'id':1,'skill':'Panchakarma','domain':'Clinical','demand':'High','required':50,'industries':12}, {'id':2,'skill':'Ayurvedic Formulation','domain':'Pharma','demand':'High','required':65,'industries':18}, {'id':3,'skill':'Clinical Documentation','domain':'Clinical','demand':'Medium','required':35,'industries':9}, {'id':4,'skill':'Clinical Research','domain':'Research','demand':'High','required':45,'industries':14}, {'id':5,'skill':'Patient Counselling','domain':'Wellness','demand':'Medium','required':40,'industries':11}]
students=[
 {'name':'Ananya Sharma','degree':'BAMS','skills':{'Panchakarma':82,'Patient Care':72,'Communication':78,'Clinical Documentation':45},'certifications':['Panchakarma Skill Training'],'projects':['Ayurvedic Patient Care Project'],'internships':['Panchakarma Clinical Internship'],'achievements':['Workshop Winner']},
 {'name':'Riya Verma','degree':'BAMS','skills':{'Kayachikitsa':86,'Ayurvedic Diagnosis':81,'Communication':84,'Clinical Documentation':76},'certifications':['Clinical Documentation'],'projects':['Clinical Case Study'],'internships':['Ayurvedic Hospital Internship'],'achievements':['Research Presentation']},
 {'name':'Kavya Singh','degree':'BAMS','skills':{'Dravyaguna':79,'Medicinal Plant Identification':88,'Research Methodology':69,'Communication':75},'certifications':['Herbal Medicine Training'],'projects':['Medicinal Plant Database'],'internships':['Herbal Medicine R&D Internship'],'achievements':['Innovation Challenge Finalist']},]
trainings=[{'id':1,'title':'Panchakarma Skill Training','type':'Certification','skills':'Panchakarma, Patient Care','duration':'4 weeks','enrolled':28,'completion':82},{'id':2,'title':'Clinical Documentation Workshop','type':'Workshop','skills':'Documentation, Communication','duration':'2 days','enrolled':36,'completion':75},{'id':3,'title':'Ayurvedic Formulation Certification','type':'Certification','skills':'Bhaishajya Kalpana, Rasashastra','duration':'6 weeks','enrolled':22,'completion':68}]
faculty=[{'id':1,'title':'Industry Mentorship Program','type':'Mentorship','partner':'AyurCare Wellness Centre','faculty':'Dr. Meera Joshi','status':'Active'},{'id':2,'title':'Clinical Research Collaboration','type':'Research Collaboration','partner':'HerbLife Research Labs','faculty':'Dr. Nitin Sharma','status':'Proposed'},{'id':3,'title':'Ayurveda FDP: Industry Practices','type':'FDP','partner':'Dhanvantari Hospitals','faculty':'Dr. Arjun Rao','status':'Scheduled'}]
challenges=[{'id':1,'title':'Digital Ayurveda Patient Record','company':'Dhanvantari Hospitals','participants':18,'deadline':'20 Oct 2026','status':'Open'},{'id':2,'title':'Herbal Product Innovation Challenge','company':'HerbLife Research Labs','participants':11,'deadline':'28 Oct 2026','status':'Open'}]
notifications=[{'text':'Ananya Sharma shortlisted for Panchakarma Therapist','time':'10 min ago','new':True},{'text':'Clinical Documentation Workshop deadline approaching','time':'1 hour ago','new':True},{'text':'New skill demand: Ayurvedic Formulation','time':'Today','new':False}]
documents=[]
verification_results=[]
global_collaborations=[
 {'id':1,'company':'Nippon Ayurveda Labs','country':'Japan','region':'Asia-Pacific','type':'Overseas Internship','mode':'Hybrid','currency':'JPY','timezone':'JST (UTC+9)','skills':'Ayurvedic Formulation, Clinical Research','status':'Active'},
 {'id':2,'company':'Global Wellness Research GmbH','country':'Germany','region':'Europe','type':'Remote Project','mode':'Remote','currency':'EUR','timezone':'CET (UTC+1)','skills':'Clinical Research, Data Analysis','status':'Active'},
 {'id':3,'company':'AyurTech Health Inc.','country':'United States','region':'North America','type':'Global Job','mode':'Remote','currency':'USD','timezone':'EST (UTC-5)','skills':'AI in Healthcare, Digital Health','status':'Open'},
]
global_skill_demands=[
 {'skill':'Global AI Ethics','country':'United States','priority':'High','companies':8},
 {'skill':'Quantum Computing','country':'Japan','priority':'Emerging','companies':4},
 {'skill':'Clinical Research','country':'Germany','priority':'High','companies':7},
 {'skill':'Digital Health','country':'United States','priority':'High','companies':11},
]

@app.context_processor
def common(): return {'notifications':notifications,'role':session.get('role','Industry Admin')}

def next_id(items): return max([x.get('id',0) for x in items] or [0])+1

@app.route('/')
def home():
 return render_template('home.html',jobs=jobs,applications=applications,internships=internships,skill_demand=skill_demand,trainings=trainings,students=students,faculty=faculty,challenges=challenges)

@app.route('/jobs',methods=['GET','POST'])
def jobs_page():
 if request.method=='POST':
  jobs.insert(0,{'id':next_id(jobs),'title':request.form['title'],'company':request.form['company'],'skills':request.form['skills'],'location':request.form['location'],'salary':request.form['salary'],'deadline':request.form['deadline'],'status':'Open'}); flash('Job posted successfully.','success'); return redirect(url_for('jobs_page'))
 q=request.args.get('q','').lower(); loc=request.args.get('location','').lower(); filtered=[j for j in jobs if q in (j['title']+' '+j['skills']).lower() and loc in j['location'].lower()]
 return render_template('jobs.html',jobs=filtered)

@app.route('/jobs/<int:job_id>/delete',methods=['POST'])
def delete_job(job_id):
 jobs[:] = [j for j in jobs if j['id']!=job_id]; flash('Job deleted.','success'); return redirect(url_for('jobs_page'))

@app.route('/recruitment')
def recruitment(): return render_template('recruitment.html',applications=applications)
@app.route('/recruitment/<int:app_id>',methods=['POST'])
def update_application(app_id):
 a=next(x for x in applications if x['id']==app_id); a['status']=request.form['status']; notifications.insert(0,{'text':f"{a['student']} application status updated to {a['status']}",'time':'Just now','new':True}); flash('Recruitment status updated.','success'); return redirect(url_for('recruitment'))

@app.route('/internships')
def internship_page(): return render_template('internships.html',internships=internships)
@app.route('/internships/<int:item_id>',methods=['POST'])
def update_internship(item_id):
 x=next(i for i in internships if i['id']==item_id); x['status']=request.form['status']; flash('Internship workflow updated.','success'); return redirect(url_for('internship_page'))

@app.route('/skill-demand',methods=['GET','POST'])
def demand():
 if request.method=='POST': skill_demand.insert(0,{'id':next_id(skill_demand),'skill':request.form['skill'],'domain':request.form['domain'],'demand':request.form['demand'],'required':int(request.form['required']),'industries':int(request.form['industries'])}); flash('Industry skill demand published and available to institutes.','success'); return redirect(url_for('demand'))
 return render_template('skill_demand.html',skill_demand=skill_demand)

@app.route('/skill-gap')
def skill_gap():
 target={'Panchakarma':80,'Patient Care':75,'Communication':70,'Clinical Documentation':65}
 rows=[]
 for s in students:
  vals=[]; missing=[]
  for skill,req in target.items():
   score=s['skills'].get(skill,0); vals.append(score);
   if score<req: missing.append(skill)
  readiness=round(sum(vals)/len(vals)); rec=[]
  for m in missing:
   rec += {'Clinical Documentation':['Clinical Documentation Workshop','Hospital Internship','Mentor Session'],'Patient Care':['Patient Care Training','Case-record Workshop'],'Panchakarma':['Panchakarma Clinical Training'],'Communication':['Communication Workshop']}.get(m,['Relevant Skill Training'])
  rows.append({'student':s['name'],'readiness':readiness,'missing':missing,'recommendations':list(dict.fromkeys(rec))})
 return render_template('skill_gap.html',rows=rows,target=target)

@app.route('/analytics')
def analytics():
 total=len(students); placed=round(100*3/5); active=sum(i['status']=='In Progress' for i in internships); completed=sum(i['status']=='Completed' for i in internships)
 return render_template('analytics.html',total=total,placed=placed,active=active,completed=completed,skill_demand=skill_demand,applications=applications,internships=internships,trainings=trainings)

@app.route('/faculty')
def faculty_page(): return render_template('faculty.html',faculty=faculty)
@app.route('/training',methods=['GET','POST'])
def training_page():
 if request.method=='POST': trainings.insert(0,{'id':next_id(trainings),'title':request.form['title'],'type':request.form['type'],'skills':request.form['skills'],'duration':request.form['duration'],'enrolled':0,'completion':0}); flash('Training/certification published.','success'); return redirect(url_for('training_page'))
 return render_template('training.html',trainings=trainings)

@app.route('/documents',methods=['GET','POST'])
def documents_page():
 if request.method=='POST':
  f=request.files.get('document');
  if f and f.filename:
   safe=os.path.basename(f.filename); f.save(UPLOAD/safe); documents.append({'name':safe,'owner':request.form.get('owner','Student'),'type':request.form.get('type','Certificate'),'status':'Pending Verification'}); flash('Document uploaded securely for verification.','success')
  return redirect(url_for('documents_page'))
 return render_template('documents.html',documents=documents)
@app.route('/documents/<int:index>/<status>',methods=['POST'])
def verify_doc(index,status):
 if 0<=index<len(documents) and status in ('Verified','Rejected'): documents[index]['status']=status; flash(f'Document {status.lower()}.','success')
 return redirect(url_for('documents_page'))
@app.route('/uploads/<path:name>')
def upload_file(name): return send_from_directory(UPLOAD,name)

@app.route('/notifications')
def notification_page(): return render_template('notifications.html',notifications=notifications)
@app.route('/challenges',methods=['GET','POST'])
def challenges_page():
 if request.method=='POST': challenges.insert(0,{'id':next_id(challenges),'title':request.form['title'],'company':request.form['company'],'participants':0,'deadline':request.form['deadline'],'status':'Open'}); flash('Innovation challenge published.','success'); return redirect(url_for('challenges_page'))
 return render_template('challenges.html',challenges=challenges)
@app.route('/challenges/<int:cid>/join',methods=['POST'])
def join_challenge(cid):
 c=next(x for x in challenges if x['id']==cid); c['participants']+=1; flash('Team participation recorded.','success'); return redirect(url_for('challenges_page'))

@app.route('/role/<role>')
def set_role(role):
 if role in ('Industry Admin','Institute Viewer','Faculty Viewer'): session['role']=role
 return redirect(request.referrer or url_for('home'))

@app.route('/document-verification', methods=['GET','POST'])
def document_verification():
    result=None
    if request.method=='POST':
        f=request.files.get('certificate')
        expected_name=request.form.get('expected_name','').strip()
        expected_cert=request.form.get('expected_certificate','').strip()
        expected_year=request.form.get('expected_year','').strip()
        if not f or not f.filename:
            flash('Please select a certificate image.','danger')
            return redirect(url_for('document_verification'))
        allowed={'.jpg','.jpeg','.png','.webp'}
        ext=Path(f.filename).suffix.lower()
        if ext not in allowed:
            flash('Forensic verification supports JPG, JPEG, PNG and WEBP images.','danger')
            return redirect(url_for('document_verification'))
        safe=secure_filename(f.filename)
        unique=f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{safe}"
        path=UPLOAD/unique; f.save(path)
        size=path.stat().st_size
        sha256=hashlib.sha256(path.read_bytes()).hexdigest()
        tamper_score=0.0; likely=False; warnings=[]; ela_file=None
        ocr={'raw_text':'','certificate_no':None,'name':None,'university':None,'year':None}
        try:
            if error_level_analysis:
                ela_path=UPLOAD/f"ela_{unique}.jpg"
                _, raw_score=error_level_analysis(str(path), save_path=str(ela_path))
                tamper_score=round(float(raw_score),2); likely=tamper_score>15.0; ela_file=ela_path.name
            else: warnings.append('ELA module unavailable; install Pillow and NumPy.')
        except Exception as e: warnings.append(f'ELA analysis could not run: {e}')
        try:
            if extract_fields: ocr=extract_fields(str(path))
            else: warnings.append('OCR module unavailable.')
        except Exception: warnings.append('OCR could not run. Install Tesseract OCR and Python OCR packages.')
        db_check={'status':'DATABASE_CHECK_UNAVAILABLE','match':False}
        try:
            if init_fraud_db:
                init_fraud_db()
            if verify_against_db:
                db_check=verify_against_db(ocr)
        except Exception as e:
            warnings.append(f'Database verification could not run: {e}')
        matches=0; checks=0
        if db_check.get('match'):
            matches += 1
        checks += 1
        for expected,actual in [(expected_name,ocr.get('name')),(expected_cert,ocr.get('certificate_no')),(expected_year,ocr.get('year'))]:
            if expected:
                checks+=1
                if actual and expected.lower() in str(actual).lower(): matches+=1
        checks+=1
        if size>0 and bool(mimetypes.guess_type(path.name)[0]): matches+=1
        match_score=(matches/checks*100) if checks else 100
        trust=max(0,min(100,round((100-min(tamper_score,50)*1.2)*0.65 + match_score*0.35)))
        status='Flagged / Suspicious' if likely or trust<60 else 'Verified Genuine'
        result={'file':unique,'size':size,'sha256':sha256[:16]+'…','tamper_score':tamper_score,'trust_score':trust,
                'status':status,'ocr':ocr,'metadata_ok':size>0,'match_score':round(match_score),'ela_file':ela_file,'database_check':db_check,'warnings':warnings}
        verification_results.insert(0,result)
        flash('AI-assisted document verification completed.','success')
    return render_template('document_verification.html',result=result,history=verification_results[:10])

@app.route('/global-collaboration', methods=['GET','POST'])
def global_collaboration():
    if request.method=='POST':
        global_collaborations.insert(0,{'id':next_id(global_collaborations),'company':request.form.get('company','International Company'),
          'country':request.form.get('country',''),'region':request.form.get('region',''),'type':request.form.get('type','Global Opportunity'),
          'mode':request.form.get('mode','Remote'),'currency':request.form.get('currency','USD'),'timezone':request.form.get('timezone','UTC'),
          'skills':request.form.get('skills',''),'status':'Open'})
        flash('Global collaboration / overseas opportunity published.','success')
        return redirect(url_for('global_collaboration'))
    return render_template('global_collaboration.html',collaborations=global_collaborations,global_skill_demands=global_skill_demands)

@app.route('/global-skill-demand', methods=['POST'])
def global_skill_demand():
    global_skill_demands.insert(0,{'skill':request.form.get('skill',''),'country':request.form.get('country',''),
      'priority':request.form.get('priority','High'),'companies':int(request.form.get('companies',0) or 0)})
    flash('Cross-border skill demand synced to the portal.','success')
    return redirect(url_for('global_collaboration'))

if __name__=='__main__':
    if init_fraud_db:
        init_fraud_db()
    app.run(debug=True)
