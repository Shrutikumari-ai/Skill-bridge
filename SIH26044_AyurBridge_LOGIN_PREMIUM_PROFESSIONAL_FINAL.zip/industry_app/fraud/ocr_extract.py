"""
ocr_extract.py

Certificate/Degree image se text fields nikaalta hai
(OCR ke through).

Requires:
    pip install pytesseract opencv-python Pillow
"""

import cv2
import pytesseract
import re


# ============================================================
# WINDOWS TESSERACT CONFIGURATION
# ============================================================

pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)


# ============================================================
# IMAGE PREPROCESSING
# ============================================================

def preprocess_image(image_path):
    """Image ko OCR ke liye clean karta hai."""

    img = cv2.imread(image_path)

    if img is None:
        raise FileNotFoundError(
            f"Image file nahi mili ya open nahi ho paayi: {image_path}"
        )

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Noise remove
    denoised = cv2.fastNlMeansDenoising(
        gray,
        h=30
    )

    # Image ko black/white mein convert
    _, thresh = cv2.threshold(
        denoised,
        150,
        255,
        cv2.THRESH_BINARY
    )

    return thresh


# ============================================================
# OCR TEXT EXTRACTION
# ============================================================

def extract_text(image_path):
    """Certificate image se raw text nikalta hai."""

    processed = preprocess_image(image_path)

    text = pytesseract.image_to_string(
        processed
    )

    return text


# ============================================================
# FIELD EXTRACTION
# ============================================================

def extract_fields(image_path):
    """
    Certificate se important fields nikaalta hai:

    - name
    - certificate_no
    - university
    - year
    - raw_text
    """

    text = extract_text(image_path)

    fields = {
        "raw_text": text,
        "certificate_no": None,
        "name": None,
        "university": None,
        "year": None,
    }

    # --------------------------------------------------------
    # Certificate Number
    # --------------------------------------------------------

    cert_match = re.search(
        r"(?:Certificate\s*(?:No|Number)?|Cert\s*No)"
        r"\s*[:\-]?\s*([A-Z0-9/\-]{6,20})",
        text,
        re.IGNORECASE
    )

    if cert_match:
        fields["certificate_no"] = (
            cert_match.group(1).strip()
        )

    # --------------------------------------------------------
    # Name
    # --------------------------------------------------------

    name_match = re.search(
        r"(?:Name|Student\s*Name)"
        r"\s*[:\-]\s*([A-Za-z.\s]{3,60})",
        text,
        re.IGNORECASE
    )

    if name_match:
        fields["name"] = (
            name_match.group(1).strip()
        )

    # --------------------------------------------------------
    # University / Institute / College
    # --------------------------------------------------------

    univ_match = re.search(
        r"(?:University|Institute|College)"
        r"\s*[:\-]?\s*([A-Za-z0-9.,&\-\s]{5,100})",
        text,
        re.IGNORECASE
    )

    if univ_match:
        fields["university"] = (
            univ_match.group(1).strip()
        )

    # --------------------------------------------------------
    # Year
    # --------------------------------------------------------

    year_match = re.search(
        r"\b(19|20)\d{2}\b",
        text
    )

    if year_match:
        fields["year"] = year_match.group(0)

    return fields


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    import sys

    if len(sys.argv) < 2:
        print(
            "Usage: python ocr_extract.py <image_path>"
        )
        sys.exit(1)

    result = extract_fields(
        sys.argv[1]
    )

    print("\nOCR RESULT")
    print("==========")
    print(result)
    