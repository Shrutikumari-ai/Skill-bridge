# SIH26044 Industry Dashboard — 13 Features
This is the existing Industry Dashboard with two additional Industry-side modules.

12. AI-Powered Document Fraud Detection: ELA forensics, OCR, metadata/integrity checks and 0–100% Trust Score.
13. Global & Foreign Company Collaboration: international jobs/internships, remote and overseas modes, USD/EUR/JPY/GBP currency fields, time zones and cross-border skill-demand sync.

## Run
cd .\SIH26044_Industry_Dashboard_COMPLETE_FINAL
python -m pip install -r requirements.txt
python app.py
Open http://127.0.0.1:5000

OCR note: install Tesseract OCR separately on Windows for OCR extraction. The app continues with other checks if Tesseract is unavailable.


### Feature 12 — AI-Powered Document Fraud Detection
The dashboard includes the supplied fraud-detection modules:
- ELA Forensics
- OCR extraction
- authorized-record database verification
- Trust Score and Genuine/Suspicious result
- verification history
- uploaded document storage

For OCR, install Tesseract OCR on Windows. The Python module expects the default path:
`C:\Program Files\Tesseract-OCR\tesseract.exe`

### Feature 13 — Global & Foreign Company Collaboration
- International company opportunities
- Overseas internships and jobs
- USD/EUR/JPY/GBP currency support
- Remote/Hybrid/Overseas modes
- Time-zone support
- Cross-border skill demand
