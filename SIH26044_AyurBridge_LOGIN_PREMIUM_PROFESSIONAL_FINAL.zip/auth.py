from flask import Blueprint, render_template, request, redirect, url_for, session, flash


auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip()
        password = request.form.get("password") or ""

        if not email or not password:
            flash("Please enter your email and password.", "danger")
            return render_template("login.html")

        # Login gate only: no database/schema is changed.
        # The existing application does not contain an email/password user model.
        # Any non-empty credentials create a session for this demo login.
        session["logged_in"] = True
        session["login_email"] = email

        next_url = session.pop("login_next", None)
        return redirect(next_url or url_for("student.index"))

    return render_template("login.html")


@auth_bp.route("/login/google", methods=["POST"])
def google_login():
    session["logged_in"] = True
    session["login_provider"] = "Google"
    session["login_email"] = "google-user@skillbridge.demo"
    return redirect(url_for("student.index"))


@auth_bp.route("/login/microsoft", methods=["POST"])
def microsoft_login():
    session["logged_in"] = True
    session["login_provider"] = "Microsoft"
    session["login_email"] = "microsoft-user@skillbridge.demo"
    return redirect(url_for("student.index"))


@auth_bp.route("/login/apple", methods=["POST"])
def apple_login():
    session["logged_in"] = True
    session["login_provider"] = "Apple"
    session["login_email"] = "apple-user@skillbridge.demo"
    return redirect(url_for("student.index"))


@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
