
import os
import sys
from pathlib import Path
from importlib.util import spec_from_file_location, module_from_spec

from flask import Flask, redirect, url_for
from werkzeug.middleware.dispatcher import DispatcherMiddleware

BASE_DIR = Path(__file__).resolve().parent


def load_module(module_name, file_path):
    """Load a Python module from an explicit project path."""
    spec = spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load {module_name} from {file_path}")
    module = module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def create_student_app():
    # The main Student + Institute application uses one shared database/model layer.
    from models import db
    from seed import seed_data
    from routes.student import student_bp
    from routes.internship import internship_bp
    from routes.roadmap import roadmap_bp
    from routes.placement import placement_bp
    from routes.learning import learning_bp
    from routes.portal import portal_bp
    from routes.application import application_bp
    from routes.eligibility import eligibility_bp
    from routes.institute import institute_bp
    from auth import auth_bp

    app = Flask(
        __name__,
        template_folder=str(BASE_DIR / "templates"),
        static_folder=str(BASE_DIR / "static"),
    )
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{BASE_DIR / 'instance' / 'sih.db'}"
    app.config["SECRET_KEY"] = "skillbridge-integrated-demo-secret"

    (BASE_DIR / "instance").mkdir(exist_ok=True)
    db.init_app(app)

    # Student routes
    app.register_blueprint(student_bp)
    app.register_blueprint(internship_bp)
    app.register_blueprint(roadmap_bp)
    app.register_blueprint(placement_bp)
    app.register_blueprint(learning_bp)
    app.register_blueprint(portal_bp)
    app.register_blueprint(application_bp)
    app.register_blueprint(eligibility_bp)

    # Institute/Aca­demia ecosystem
    app.register_blueprint(institute_bp)
    app.register_blueprint(auth_bp)

    with app.app_context():
        db.create_all()
        seed_data()

    return app


def create_mounted_app():
    student_app = create_student_app()

    # Industry project is kept as an independent Flask module so its
    # existing 13-feature dashboard, data and UI remain intact.
    industry_dir = BASE_DIR / "industry_app"
    industry_dir_str = str(industry_dir)
    sys.path.insert(0, industry_dir_str)
    try:
        industry_module = load_module(
            "skillbridge_industry_app",
            industry_dir / "app.py",
        )
        industry_app = industry_module.app
    finally:
        if industry_dir_str in sys.path:
            sys.path.remove(industry_dir_str)

    # Standalone certificate fraud-verification app.
    fraud_dir = BASE_DIR / "fraud_app"
    fraud_dir_str = str(fraud_dir)
    sys.path.insert(0, fraud_dir_str)
    try:
        fraud_module = load_module(
            "skillbridge_fraud_app",
            fraud_dir / "app.py",
        )
        fraud_app = fraud_module.app
    finally:
        if fraud_dir_str in sys.path:
            sys.path.remove(fraud_dir_str)

    # The student app is the main dashboard. Industry and Fraud are available
    # inside the same localhost server under dedicated paths.
    application = DispatcherMiddleware(
        student_app,
        {
            "/industry": industry_app,
            "/fraud": fraud_app,
        },
    )
    return application


# Flask-compatible main app for normal tooling/imports.
app = create_student_app()

# WSGI application used by the integrated server.
integrated_app = create_mounted_app()


if __name__ == "__main__":
    from werkzeug.serving import run_simple
    print("=" * 60)
    print("SKILLBRIDGE AYURVEDA - INTEGRATED PLATFORM")
    print("Student + Institute + Industry + Fraud Detection")
    print("=" * 60)
    print("Student:  http://127.0.0.1:5000/")
    print("Institute:http://127.0.0.1:5000/institute/dashboard")
    print("Industry: http://127.0.0.1:5000/industry/")
    print("Fraud:   http://127.0.0.1:5000/fraud/")
    print("=" * 60)
    run_simple(
        "127.0.0.1",
        5000,
        integrated_app,
        use_reloader=False,
        use_debugger=True,
    )
