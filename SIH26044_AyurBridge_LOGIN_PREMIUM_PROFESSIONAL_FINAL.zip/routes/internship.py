from flask import Blueprint, render_template, request, session, redirect, url_for

from models import Internship, Student
from services import SkillMapper


internship_bp = Blueprint("internship", __name__)


# =========================================================
# GENERAL OPPORTUNITIES
# =========================================================

@internship_bp.route("/internships")
def list_internships():

    # Check whether a student is already registered
    student_id = session.get("student_id")

    # If student is registered, open personalized opportunities
    if student_id:

        return redirect(
            url_for(
                "internship.student_internships",
                student_id=student_id,
                sector="both"
            )
        )

    # Otherwise show all opportunities normally
    internships = Internship.query.all()

    return render_template(
        "internships.html",
        internships=internships
    )


# =========================================================
# PERSONALIZED STUDENT OPPORTUNITIES
# =========================================================

@internship_bp.route("/internships/<int:student_id>")
def student_internships(student_id):

    student = Student.query.get_or_404(student_id)

    # -----------------------------------------------------
    # STUDENT LOCATION
    # -----------------------------------------------------

    city = (student.city or "").strip().lower()
    state = (student.state or "").strip().lower()

    # -----------------------------------------------------
    # GOVERNMENT / PRIVATE / BOTH FILTER
    # -----------------------------------------------------

    sector_filter = request.args.get(
        "sector",
        "both"
    ).strip().lower()

    # -----------------------------------------------------
    # ALL INTERNSHIPS
    # -----------------------------------------------------

    internships = Internship.query.all()

    matched_results = []

    # -----------------------------------------------------
    # STUDENT SKILLS
    # -----------------------------------------------------

    student_skills = set(
        student.skill_list()
    )

    # -----------------------------------------------------
    # CHECK EVERY INTERNSHIP
    # -----------------------------------------------------

    for internship in internships:

        # =================================================
        # 1. LOCATION MATCH
        # =================================================

        internship_city = (
            internship.city or ""
        ).strip().lower()

        internship_state = (
            internship.state or ""
        ).strip().lower()

        location_match = False

        # Same city = strongest location match
        if (
            city
            and internship_city
            and city == internship_city
        ):
            location_match = True

        # Same state = also consider
        elif (
            state
            and internship_state
            and state == internship_state
        ):
            location_match = True

        # No location specified = don't reject opportunity
        elif (
            not internship_city
            and not internship_state
        ):
            location_match = True

        # =================================================
        # 2. SECTOR FILTER
        # =================================================

        internship_sector = (
            internship.sector or ""
        ).strip().lower()

        if sector_filter == "government":

            if internship_sector != "government":
                continue

        elif sector_filter == "private":

            if internship_sector != "private":
                continue

        # =================================================
        # 3. SKILL MATCH
        # =================================================

        required_skills = set(
            internship.required_skill_list()
        )

        if required_skills:

            skill_matches = (
                student_skills.intersection(
                    required_skills
                )
            )

            skill_match_percentage = round(
                (
                    len(skill_matches)
                    / len(required_skills)
                ) * 100,
                2
            )

        else:

            skill_matches = set()
            skill_match_percentage = 100

        # =================================================
        # 4. CAREER FIELD MATCH
        # =================================================

        desired_field = (
            student.desired_field or ""
        ).strip().lower()

        internship_field = (
            internship.field or ""
        ).strip().lower()

        field_match = False

        if (
            desired_field
            and internship_field
        ):

            if (
                desired_field in internship_field
                or internship_field in desired_field
            ):
                field_match = True

        # =================================================
        # 5. LOCATION SCORE
        # =================================================

        location_score = 0

        # Same city
        if (
            city
            and internship_city
            and city == internship_city
        ):

            location_score = 100

        # Same state
        elif (
            state
            and internship_state
            and state == internship_state
        ):

            location_score = 70

        # No location information
        elif (
            not internship_city
            and not internship_state
        ):

            location_score = 40

        # =================================================
        # 6. CAREER FIELD SCORE
        # =================================================

        field_score = 100 if field_match else 0

        # =================================================
        # 7. FINAL PERSONALIZED MATCH SCORE
        # =================================================
        #
        # Skills       = 50%
        # Location     = 30%
        # Career Field = 20%
        #

        match_percentage = round(
            (
                skill_match_percentage * 0.50
                + location_score * 0.30
                + field_score * 0.20
            ),
            2
        )

        # =================================================
        # 8. ADD RESULT
        # =================================================

        matched_results.append(
            {
                "internship": internship,

                "match_percentage":
                    match_percentage,

                "skill_match_percentage":
                    skill_match_percentage,

                "location_match":
                    location_match,

                "field_match":
                    field_match,

                "matched_skills":
                    sorted(skill_matches),

                "missing_skills":
                    sorted(
                        required_skills
                        - student_skills
                    )
            }
        )

    # =====================================================
    # SORT BY HIGHEST MATCH
    # =====================================================

    matched_results.sort(
        key=lambda x: x["match_percentage"],
        reverse=True
    )

    # =====================================================
    # RENDER OPPORTUNITIES PAGE
    # =====================================================

    return render_template(
        "internships.html",

        student=student,

        internships=matched_results,

        sector_filter=sector_filter
    )