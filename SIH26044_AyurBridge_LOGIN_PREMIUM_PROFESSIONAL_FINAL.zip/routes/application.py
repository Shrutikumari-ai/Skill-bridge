from flask import Blueprint, render_template, redirect, url_for, session, flash

from models import db, Application, Student, Internship


application_bp = Blueprint("application", __name__)


# ==========================================
# APPLY FOR OPPORTUNITY
# ==========================================

@application_bp.route("/apply/<int:internship_id>", methods=["GET", "POST"])
def apply(internship_id):

    student_id = session.get("student_id")

    if not student_id:
        return redirect(url_for("student.register"))

    student = Student.query.get_or_404(student_id)

    internship = Internship.query.get_or_404(internship_id)

    existing_application = Application.query.filter_by(
        student_id=student_id,
        internship_id=internship_id
    ).first()

    if existing_application:

        flash(
            "You have already applied for this opportunity.",
            "info"
        )

        return redirect(
            url_for("application.my_applications")
        )

    new_application = Application(
        student_id=student_id,
        internship_id=internship_id,
        status="Applied"
    )

    db.session.add(new_application)

    db.session.commit()

    flash(
        "Application submitted successfully!",
        "success"
    )

    return redirect(
        url_for("application.my_applications")
    )


# ==========================================
# MY APPLICATIONS
# ==========================================

@application_bp.route("/my-applications")
def my_applications():

    student_id = session.get("student_id")

    if not student_id:
        return redirect(url_for("student.register"))

    applications = (
        Application.query
        .filter_by(student_id=student_id)
        .order_by(Application.applied_at.desc())
        .all()
    )

    return render_template(
        "my_applications.html",
        applications=applications
    )


# ==========================================
# APPLICATION DETAILS
# ==========================================

@application_bp.route("/application/<int:application_id>")
def application_details(application_id):

    student_id = session.get("student_id")

    if not student_id:
        return redirect(url_for("student.register"))

    application = (
        Application.query
        .filter_by(
            id=application_id,
            student_id=student_id
        )
        .first_or_404()
    )

    return render_template(
        "application_details.html",
        application=application
    )