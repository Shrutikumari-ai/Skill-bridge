from flask import (
    Blueprint,
    render_template,
    redirect,
    url_for,
    session
)


portal_bp = Blueprint(
    "portal",
    __name__
)


# ==========================================
# PORTAL SELECTION
# ==========================================

@portal_bp.route("/portals")
def portals():

    return render_template(
        "portals.html"
    )


# ==========================================
# STUDENT PORTAL
# ==========================================

@portal_bp.route(
    "/student-dashboard"
)
def student_dashboard():

    student_id = session.get(
        "student_id"
    )


    # Agar student already registered hai
    # to directly dashboard open hoga

    if student_id:

        return redirect(

            url_for(

                "student.dashboard",

                student_id=student_id
            )
        )


    # First time user
    # registration par jayega

    return redirect(

        url_for(
            "student.register"
        )
    )


# ==========================================
# INDUSTRY DASHBOARD
# ==========================================

@portal_bp.route(
    "/industry-dashboard"
)
def industry_dashboard():

    return render_template(
        "industry_dashboard.html"
    )


# ==========================================
# ACADEMIA DASHBOARD
# ==========================================

@portal_bp.route(
    "/academia-dashboard"
)
def academia_dashboard():

    return render_template(
        "academia_dashboard.html"
    )