from flask import Blueprint, render_template, request
from models import (
    db,
    Student,
    AssessmentQuestion,
    AssessmentAttempt,
    AssessmentAnswer
)
from services import GapAnalyzer


assessment_bp = Blueprint("assessment", __name__)


@assessment_bp.route("/assessment/<int:student_id>", methods=["GET", "POST"])
def assessment(student_id):

    student = Student.query.get_or_404(student_id)

    # -----------------------------
    # SHOW 20 QUESTIONS
    # -----------------------------
    if request.method == "GET":

        questions = (
            AssessmentQuestion.query
            .order_by(AssessmentQuestion.id)
            .limit(20)
            .all()
        )

        return render_template(
            "assessment.html",
            student=student,
            questions=questions
        )

    # -----------------------------
    # GET SAME 20 QUESTIONS
    # -----------------------------
    questions = (
        AssessmentQuestion.query
        .order_by(AssessmentQuestion.id)
        .limit(20)
        .all()
    )

    score = 0

    category_total = {}
    category_correct = {}

    # -----------------------------
    # CHECK ANSWERS
    # -----------------------------
    for question in questions:

        selected = request.form.get(
            f"question_{question.id}"
        )

        category = question.category or "general"

        category_total[category] = (
            category_total.get(category, 0) + 1
        )

        if (
            selected
            and question.correct_answer
            and selected.upper()
            == question.correct_answer.upper()
        ):

            score += 1

            category_correct[category] = (
                category_correct.get(category, 0) + 1
            )

    # -----------------------------
    # OVERALL SCORE
    # -----------------------------
    total = len(questions)

    percentage = (
        round((score / total) * 100, 2)
        if total
        else 0
    )

    # -----------------------------
    # ELIGIBILITY STATUS
    # -----------------------------
    if percentage >= 60:
        status = "Eligible"

    elif percentage >= 40:
        status = "Partially Eligible"

    else:
        status = "Not Yet Eligible"

    # -----------------------------
    # GET PREVIOUS ATTEMPT
    # BEFORE SAVING NEW ONE
    # -----------------------------
    previous_attempt = (
        AssessmentAttempt.query
        .filter_by(student_id=student.id)
        .order_by(AssessmentAttempt.id.desc())
        .first()
    )

    previous_percentage = (
        previous_attempt.score_percentage
        if previous_attempt
        else None
    )

    # -----------------------------
    # CALCULATE IMPROVEMENT
    # -----------------------------
    improvement = None

    if previous_percentage is not None:
        improvement = round(
            percentage - previous_percentage,
            2
        )

    # -----------------------------
    # SAVE NEW ATTEMPT
    # -----------------------------
    attempt = AssessmentAttempt(
        student_id=student.id,
        total_questions=total,
        correct_answers=score,
        score_percentage=percentage,
        status=status
    )

    db.session.add(attempt)
    db.session.flush()

    # -----------------------------
    # SAVE INDIVIDUAL ANSWERS
    # -----------------------------
    for question in questions:

        selected = request.form.get(
            f"question_{question.id}"
        )

        is_correct = (
            selected is not None
            and question.correct_answer
            and selected.upper()
            == question.correct_answer.upper()
        )

        answer = AssessmentAnswer(
            attempt_id=attempt.id,
            question_id=question.id,
            selected_answer=selected,
            is_correct=is_correct
        )

        db.session.add(answer)

    db.session.commit()

    # -----------------------------
    # CATEGORY SCORES
    # -----------------------------
    category_scores = {}

    for category, total_questions in category_total.items():

        correct = category_correct.get(
            category,
            0
        )

        category_scores[category] = round(
            (correct / total_questions) * 100,
            2
        )

    # -----------------------------
    # PERSONALIZED ROADMAP
    # -----------------------------
    roadmap = GapAnalyzer.generate_assessment_roadmap(
        category_scores,
        threshold=60
    )

    # -----------------------------
    # SKILL GAPS
    # -----------------------------
    skill_gaps = [
        item["skill"]
        for item in roadmap
    ]

    # -----------------------------
    # RESULT PAGE
    # -----------------------------
    return render_template(
        "assessment_result.html",
        student=student,
        attempt=attempt,
        score=score,
        percentage=percentage,
        status=status,
        category_scores=category_scores,
        skill_gaps=skill_gaps,
        roadmap=roadmap,

        # RE-ASSESSMENT DATA
        previous_attempt=previous_attempt,
        previous_percentage=previous_percentage,
        improvement=improvement
    )