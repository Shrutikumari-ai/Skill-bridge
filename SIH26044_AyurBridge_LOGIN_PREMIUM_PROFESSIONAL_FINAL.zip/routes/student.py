from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash
)

from models import (
    db,
    Student,
    Internship,
    AssessmentQuestion,
    AssessmentAttempt,
    AssessmentAnswer,
    LearningProgress
)

from services import AutomatedFramework


student_bp = Blueprint("student", __name__)


# ============================================================
# HOME PAGE
# ============================================================

@student_bp.route("/")
def index():
    if not session.get("logged_in"):
        session["login_next"] = url_for("student.index")
        return redirect(url_for("auth.login"))
    return render_template("index.html")


# ============================================================
# STUDENT REGISTER
# ============================================================

@student_bp.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        student = Student(
            name=request.form["name"],
            status=request.form["status"],
            degree=request.form.get("degree"),
            certificates=request.form.get("certificates"),
            college=request.form.get("college"),
            year=request.form.get("year") or None,
            experience=request.form.get("experience"),
            specialization=request.form.get("specialization"),
            desired_field=request.form.get("desired_field"),
            skills=request.form.get("skills"),
            city=request.form.get("city"),
            state=request.form.get("state")
        )

        db.session.add(student)
        db.session.commit()

        # Remember current student
        session["student_id"] = student.id

        # First assessment
        return redirect(
            url_for(
                "student.assessment",
                student_id=student.id
            )
        )

    return render_template("register.html")


# ============================================================
# STUDENT DASHBOARD
# ============================================================

@student_bp.route("/student-dashboard/<int:student_id>")
def dashboard(student_id):

    student = Student.query.get_or_404(student_id)

    # Store student in session
    session["student_id"] = student.id

    # ========================================================
    # LATEST ASSESSMENT
    # ========================================================

    attempt = (
        AssessmentAttempt.query
        .filter_by(student_id=student.id)
        .order_by(AssessmentAttempt.id.desc())
        .first()
    )

    assessment_score = 0

    if attempt:
        assessment_score = round(
            attempt.score_percentage or 0,
            2
        )

    # ========================================================
    # CATEGORY SKILL PROFILE
    # ========================================================

    category_scores = {
        "domain": 0,
        "clinical": 0,
        "pharmacy": 0,
        "research": 0,
        "public_health": 0,
        "communication": 0,
        "soft_skills": 0
    }

    category_names = {
        "domain": "Ayurveda Domain Knowledge",
        "clinical": "Clinical & Patient Care",
        "pharmacy": "Ayurvedic Pharmacy",
        "research": "Research & Clinical Research",
        "public_health": "AYUSH & Public Health",
        "communication": "Communication",
        "soft_skills": "Teamwork & Professional Skills"
    }

    if attempt:

        answers = (
            AssessmentAnswer.query
            .filter_by(attempt_id=attempt.id)
            .all()
        )

        category_stats = {}

        for answer in answers:

            question = AssessmentQuestion.query.get(
                answer.question_id
            )

            if not question:
                continue

            category = question.category

            if category not in category_stats:

                category_stats[category] = {
                    "correct": 0,
                    "total": 0
                }

            category_stats[category]["total"] += 1

            if answer.is_correct:
                category_stats[category]["correct"] += 1

        for category, stats in category_stats.items():

            if stats["total"] > 0:

                score = round(
                    (
                        stats["correct"]
                        /
                        stats["total"]
                    ) * 100,
                    2
                )

                category_scores[category] = score

    # ========================================================
    # STRONG SKILLS
    # ========================================================

    strong_skills = []

    for category, score in category_scores.items():

        if score >= 60:

            strong_skills.append({
                "name": category_names.get(
                    category,
                    category.replace(
                        "_",
                        " "
                    ).title()
                ),
                "score": score
            })

    # ========================================================
    # SKILL GAPS
    # ========================================================

    skill_gaps = []

    for category, score in category_scores.items():

        if score < 60:

            skill_gaps.append({
                "name": category_names.get(
                    category,
                    category.replace(
                        "_",
                        " "
                    ).title()
                ),
                "score": score,
                "required": 60,
                "gap": round(
                    60 - score,
                    2
                )
            })

    # ========================================================
    # RECOMMENDED OPPORTUNITIES
    # ========================================================

    internships = Internship.query.all()

    recommended_opportunities = []

    student_skills = (
        student.skill_list()
        if hasattr(student, "skill_list")
        else []
    )

    desired_field = (
        student.desired_field or ""
    ).lower()

    student_city = (
        student.city or ""
    ).lower()

    student_state = (
        student.state or ""
    ).lower()

    for internship in internships:

        required_skills = (
            internship.required_skill_list()
            if hasattr(
                internship,
                "required_skill_list"
            )
            else []
        )

        # ----------------------------------------------------
        # SKILL MATCH
        # ----------------------------------------------------

        if required_skills:

            matched_skills = sum(
                1
                for skill in required_skills
                if skill in student_skills
            )

            skill_score = (
                matched_skills
                /
                len(required_skills)
            ) * 100

        else:

            skill_score = 0

        # ----------------------------------------------------
        # LOCATION MATCH
        # ----------------------------------------------------

        location_score = 0

        internship_city = (
            internship.city or ""
        ).lower()

        internship_state = (
            internship.state or ""
        ).lower()

        if (
            student_city
            and internship_city == student_city
        ):

            location_score = 100

        elif (
            student_state
            and internship_state == student_state
        ):

            location_score = 70

        else:

            location_score = 30

        # ----------------------------------------------------
        # FIELD MATCH
        # ----------------------------------------------------

        field_score = 0

        internship_field = (
            internship.field or ""
        ).lower()

        if (
            desired_field
            and (
                desired_field in internship_field
                or internship_field in desired_field
            )
        ):

            field_score = 100

        else:

            field_score = 40

        # ----------------------------------------------------
        # FINAL MATCH SCORE
        # ----------------------------------------------------

        match_score = round(
            (
                skill_score * 0.50
            )
            +
            (
                location_score * 0.30
            )
            +
            (
                field_score * 0.20
            ),
            2
        )

        recommended_opportunities.append({
            "internship": internship,
            "score": match_score
        })

    recommended_opportunities.sort(
        key=lambda item: item["score"],
        reverse=True
    )

    recommended_opportunities = (
        recommended_opportunities[:5]
    )

    # ========================================================
    # READINESS STATUS
    # ========================================================

    if not attempt:

        readiness = "Assessment Pending"

        readiness_class = "pending"

        readiness_message = (
            "Complete your skill assessment "
            "to understand your career readiness."
        )

    elif assessment_score >= 75:

        readiness = "Highly Career Ready"

        readiness_class = "excellent"

        readiness_message = (
            "Your readiness score is strong. "
            "You can explore suitable career opportunities."
        )

    elif assessment_score >= 60:

        readiness = "Career Ready"

        readiness_class = "good"

        readiness_message = (
            "Your assessment indicates good career readiness. "
            "Continue improving your skills."
        )

    elif assessment_score >= 40:

        readiness = "Needs Improvement"

        readiness_class = "warning"

        readiness_message = (
            "Focus on your identified skill gaps "
            "and complete the recommended learning."
        )

    else:

        readiness = "Needs Skill Development"

        readiness_class = "danger"

        readiness_message = (
            "Strengthen your foundational skills "
            "through the recommended learning roadmap."
        )

    # ========================================================
    # RE-ASSESSMENT UNLOCK STATUS
    # ========================================================

    assessment_attempts = (
        AssessmentAttempt.query
        .filter_by(
            student_id=student.id
        )
        .count()
    )

    learning_completed = (
        LearningProgress.query
        .filter(
            LearningProgress.student_id == student.id,
            LearningProgress.progress >= 66
        )
        .first()
        is not None
    )

    can_reassess = (
        assessment_attempts == 0
        or learning_completed
    )

    # ========================================================
    # DASHBOARD STATS
    # ========================================================

    dashboard_stats = {

        "assessment_score":
            assessment_score,

        "strong_skills":
            len(strong_skills),

        "skill_gaps":
            len(skill_gaps),

        "opportunities":
            len(recommended_opportunities)
    }

    # ========================================================
    # NEXT ACTION
    # ========================================================

    if not attempt:

        next_action = (
            "Complete your skill assessment"
        )

    elif not learning_completed:

        next_action = (
            "Complete your learning and practice "
            "to unlock re-assessment"
        )

    elif skill_gaps:

        next_action = (
            "Complete learning and take the "
            "re-assessment to measure improvement"
        )

    else:

        next_action = (
            "Explore matched opportunities"
        )

    # ========================================================
    # RENDER DASHBOARD
    # ========================================================

    return render_template(

        "student_portal.html",

        student=student,

        attempt=attempt,

        assessment_score=assessment_score,

        category_scores=category_scores,

        category_names=category_names,

        strong_skills=strong_skills,

        skill_gaps=skill_gaps,

        recommended_opportunities=
            recommended_opportunities,

        readiness=readiness,

        readiness_status=readiness,

        readiness_class=readiness_class,

        readiness_message=readiness_message,

        dashboard_stats=dashboard_stats,

        next_action=next_action,

        can_reassess=can_reassess,

        learning_completed=learning_completed,

        assessment_attempts=assessment_attempts
    )


# ============================================================
# INTERNSHIP / OPPORTUNITY MATCHING
# ============================================================

@student_bp.route("/match/<int:student_id>")
def match(student_id):

    student = Student.query.get_or_404(student_id)

    sector = request.args.get(
        "sector",
        "both"
    )

    return redirect(

        url_for(
            "internship.student_internships",

            student_id=student.id,

            sector=sector
        )
    )


# ============================================================
# GET BALANCED 25 QUESTIONS
# ============================================================

def get_assessment_questions():

    selected_questions = []

    category_limits = {

        "domain": 5,

        "clinical": 4,

        "pharmacy": 3,

        "research": 4,

        "public_health": 4,

        "communication": 2,

        "soft_skills": 3
    }

    for category, limit in category_limits.items():

        category_questions = (

            AssessmentQuestion.query

            .filter_by(
                category=category
            )

            .order_by(
                AssessmentQuestion.id.asc()
            )

            .limit(limit)

            .all()
        )

        selected_questions.extend(
            category_questions
        )

    return selected_questions[:25]


# ============================================================
# CHECK RE-ASSESSMENT ACCESS
# ============================================================

def reassessment_unlocked(student_id):

    student = Student.query.get_or_404(
        student_id
    )

    attempts_count = (

        AssessmentAttempt.query

        .filter_by(
            student_id=student.id
        )

        .count()
    )

    # --------------------------------------------------------
    # FIRST ASSESSMENT
    # --------------------------------------------------------

    if attempts_count == 0:

        return True

    # --------------------------------------------------------
    # AFTER FIRST ASSESSMENT:
    # PRACTICE MUST BE PASSED
    # --------------------------------------------------------

    completed_learning = (

        LearningProgress.query

        .filter(
            LearningProgress.student_id
            == student.id,

            LearningProgress.progress
            >= 66
        )

        .first()
    )

    return completed_learning is not None


# ============================================================
# ASSESSMENT PAGE
# ============================================================

@student_bp.route(
    "/assessment/<int:student_id>"
)
def assessment(student_id):

    student = Student.query.get_or_404(
        student_id
    )

    session["student_id"] = student.id

    # --------------------------------------------------------
    # RE-ASSESSMENT LOCK
    # --------------------------------------------------------

    if not reassessment_unlocked(
        student.id
    ):

        flash(
            "Complete Learning and Practice before taking the assessment again.",
            "warning"
        )

        return redirect(

            url_for(
                "learning.learning_home",

                student_id=student.id
            )
        )

    # --------------------------------------------------------
    # QUESTIONS
    # --------------------------------------------------------

    questions = (
        get_assessment_questions()
    )

    if not questions:

        return (
            "No assessment questions found."
        )

    return render_template(

        "assessment.html",

        student=student,

        questions=questions
    )


# ============================================================
# SUBMIT ASSESSMENT
# ============================================================

@student_bp.route(
    "/assessment/<int:student_id>/submit",
    methods=["POST"]
)
def submit_assessment(student_id):

    student = Student.query.get_or_404(
        student_id
    )

    session["student_id"] = student.id

    # --------------------------------------------------------
    # RE-ASSESSMENT LOCK
    # --------------------------------------------------------

    if not reassessment_unlocked(
        student.id
    ):

        flash(
            "Complete Learning and Practice before taking the assessment again.",
            "warning"
        )

        return redirect(

            url_for(
                "learning.learning_home",

                student_id=student.id
            )
        )

    # --------------------------------------------------------
    # QUESTIONS
    # --------------------------------------------------------

    questions = (
        get_assessment_questions()
    )

    if not questions:

        return (
            "No assessment questions found."
        )

    # ========================================================
    # PREVIOUS ATTEMPT
    # ========================================================

    previous_attempt = (

        AssessmentAttempt.query

        .filter_by(
            student_id=student.id
        )

        .order_by(
            AssessmentAttempt.id.desc()
        )

        .first()
    )

    previous_percentage = (

        previous_attempt.score_percentage

        if previous_attempt

        else None
    )

    # ========================================================
    # CREATE NEW ATTEMPT
    # ========================================================

    attempt = AssessmentAttempt(

        student_id=student.id,

        total_questions=len(
            questions
        ),

        correct_answers=0,

        score_percentage=0,

        status="completed"
    )

    db.session.add(attempt)

    db.session.commit()

    # ========================================================
    # CATEGORY STATS
    # ========================================================

    category_stats = {

        "domain":
            {
                "correct": 0,
                "total": 0
            },

        "clinical":
            {
                "correct": 0,
                "total": 0
            },

        "pharmacy":
            {
                "correct": 0,
                "total": 0
            },

        "research":
            {
                "correct": 0,
                "total": 0
            },

        "public_health":
            {
                "correct": 0,
                "total": 0
            },

        "communication":
            {
                "correct": 0,
                "total": 0
            },

        "soft_skills":
            {
                "correct": 0,
                "total": 0
            }
    }

    correct_count = 0

    # ========================================================
    # CHECK ANSWERS
    # ========================================================

    for question in questions:

        selected_answer = request.form.get(
            f"question_{question.id}"
        )

        is_correct = (

            selected_answer is not None

            and

            selected_answer.upper()
            ==
            question.correct_answer.upper()
        )

        if is_correct:

            correct_count += 1

        category = question.category

        if category not in category_stats:

            category_stats[category] = {

                "correct": 0,

                "total": 0
            }

        category_stats[
            category
        ]["total"] += 1

        if is_correct:

            category_stats[
                category
            ]["correct"] += 1

        answer = AssessmentAnswer(

            attempt_id=attempt.id,

            question_id=question.id,

            selected_answer=selected_answer,

            is_correct=is_correct
        )

        db.session.add(answer)

    # ========================================================
    # TOTAL SCORE
    # ========================================================

    total_questions = len(
        questions
    )

    if total_questions:

        percentage = round(

            (
                correct_count
                /
                total_questions
            ) * 100,

            2
        )

    else:

        percentage = 0

    # ========================================================
    # CATEGORY PERCENTAGE HELPER
    # ========================================================

    def category_percentage(category):

        total = (
            category_stats[category]["total"]
        )

        correct = (
            category_stats[category]["correct"]
        )

        if total == 0:

            return 0

        return round(

            (
                correct
                /
                total
            ) * 100,

            2
        )

    # ========================================================
    # CATEGORY SCORES
    # ========================================================

    domain_score = (
        category_percentage("domain")
    )

    clinical_score = (
        category_percentage("clinical")
    )

    pharmacy_score = (
        category_percentage("pharmacy")
    )

    research_score = (
        category_percentage("research")
    )

    public_health_score = (
        category_percentage(
            "public_health"
        )
    )

    communication_score = (
        category_percentage(
            "communication"
        )
    )

    soft_skills_score = (
        category_percentage(
            "soft_skills"
        )
    )

    # ========================================================
    # UPDATE ATTEMPT
    # ========================================================

    attempt.correct_answers = (
        correct_count
    )

    attempt.score_percentage = (
        percentage
    )

    attempt.technical_score = (
        pharmacy_score
    )

    attempt.domain_score = (
        domain_score
    )

    attempt.problem_solving_score = (
        clinical_score
    )

    attempt.aptitude_score = (
        public_health_score
    )

    attempt.communication_score = (
        communication_score
    )

    attempt.soft_skills_score = (
        soft_skills_score
    )

    # ========================================================
    # STATUS
    # ========================================================

    if percentage >= 60:

        status = "Eligible"

    elif percentage >= 40:

        status = "Partially Eligible"

    else:

        status = "Not Yet Eligible"

    attempt.status = status

    db.session.commit()

    # ========================================================
    # IMPROVEMENT
    # ========================================================

    improvement = None

    if previous_percentage is not None:

        improvement = round(

            percentage
            -
            previous_percentage,

            2
        )

    # ========================================================
    # SKILL GAPS
    # ========================================================

    skill_gaps = []

    category_display_names = {

        "domain":
            "Ayurveda Domain Knowledge",

        "clinical":
            "Clinical & Patient Care",

        "pharmacy":
            "Ayurvedic Pharmacy",

        "research":
            "Research & Clinical Research",

        "public_health":
            "AYUSH & Public Health",

        "communication":
            "Communication",

        "soft_skills":
            "Teamwork & Professional Skills"
    }

    for category, stats in (
        category_stats.items()
    ):

        if stats["total"] == 0:

            continue

        score = round(

            (
                stats["correct"]
                /
                stats["total"]
            ) * 100,

            2
        )

        if score < 60:

            skill_gaps.append({

                "name":
                    category_display_names.get(

                        category,

                        category.replace(
                            "_",
                            " "
                        ).title()
                    ),

                "score":
                    score,

                "required":
                    60,

                "gap":
                    round(
                        60 - score,
                        2
                    )
            })

    # ========================================================
    # RESULT
    # ========================================================

    return render_template(

        "assessment_result.html",

        student=student,

        attempt=attempt,

        questions=questions,

        category_stats=category_stats,

        percentage=percentage,

        correct_count=correct_count,

        total_questions=total_questions,

        domain_score=domain_score,

        clinical_score=clinical_score,

        pharmacy_score=pharmacy_score,

        research_score=research_score,

        public_health_score=
            public_health_score,

        communication_score=
            communication_score,

        soft_skills_score=
            soft_skills_score,

        status=status,

        skill_gaps=skill_gaps,

        # ----------------------------------------------------
        # RE-ASSESSMENT DATA
        # ----------------------------------------------------

        previous_attempt=
            previous_attempt,

        previous_percentage=
            previous_percentage,

        improvement=
            improvement,

        is_reassessment=
            previous_attempt is not None
    )


# ============================================================
# ASSESSMENT RESULT PAGE
# ============================================================

@student_bp.route(
    "/assessment/<int:student_id>/result"
)
def assessment_result(student_id):

    student = Student.query.get_or_404(
        student_id
    )

    session["student_id"] = student.id

    # ========================================================
    # LATEST ATTEMPT
    # ========================================================

    attempt = (

        AssessmentAttempt.query

        .filter_by(
            student_id=student.id
        )

        .order_by(
            AssessmentAttempt.id.desc()
        )

        .first()
    )

    if not attempt:

        return redirect(

            url_for(
                "student.assessment",

                student_id=student.id
            )
        )

    # ========================================================
    # PREVIOUS ATTEMPT
    # ========================================================

    previous_attempt = (

        AssessmentAttempt.query

        .filter(
            AssessmentAttempt.student_id
            == student.id,

            AssessmentAttempt.id
            < attempt.id
        )

        .order_by(
            AssessmentAttempt.id.desc()
        )

        .first()
    )

    previous_percentage = (

        previous_attempt.score_percentage

        if previous_attempt

        else None
    )

    # ========================================================
    # IMPROVEMENT
    # ========================================================

    improvement = None

    if previous_percentage is not None:

        improvement = round(

            (
                attempt.score_percentage or 0
            )
            -
            previous_percentage,

            2
        )

    # ========================================================
    # CATEGORY STATS
    # ========================================================

    category_stats = {

        "domain":
            {
                "correct": 0,
                "total": 0
            },

        "clinical":
            {
                "correct": 0,
                "total": 0
            },

        "pharmacy":
            {
                "correct": 0,
                "total": 0
            },

        "research":
            {
                "correct": 0,
                "total": 0
            },

        "public_health":
            {
                "correct": 0,
                "total": 0
            },

        "communication":
            {
                "correct": 0,
                "total": 0
            },

        "soft_skills":
            {
                "correct": 0,
                "total": 0
            }
    }

    # ========================================================
    # ANSWERS
    # ========================================================

    answers = (

        AssessmentAnswer.query

        .filter_by(
            attempt_id=attempt.id
        )

        .all()
    )

    for answer in answers:

        question = (
            AssessmentQuestion.query.get(
                answer.question_id
            )
        )

        if not question:

            continue

        category = question.category

        if category not in category_stats:

            category_stats[category] = {

                "correct": 0,

                "total": 0
            }

        category_stats[
            category
        ]["total"] += 1

        if answer.is_correct:

            category_stats[
                category
            ]["correct"] += 1

    # ========================================================
    # CATEGORY PERCENTAGE
    # ========================================================

    def category_percentage(category):

        total = (
            category_stats[category]["total"]
        )

        correct = (
            category_stats[category]["correct"]
        )

        if total == 0:

            return 0

        return round(

            (
                correct
                /
                total
            ) * 100,

            2
        )

    domain_score = (
        category_percentage("domain")
    )

    clinical_score = (
        category_percentage("clinical")
    )

    pharmacy_score = (
        category_percentage("pharmacy")
    )

    research_score = (
        category_percentage("research")
    )

    public_health_score = (
        category_percentage(
            "public_health"
        )
    )

    communication_score = (
        category_percentage(
            "communication"
        )
    )

    soft_skills_score = (
        category_percentage(
            "soft_skills"
        )
    )

    percentage = (
        attempt.score_percentage or 0
    )

    # ========================================================
    # STATUS
    # ========================================================

    if percentage >= 60:

        status = "Eligible"

    elif percentage >= 40:

        status = "Partially Eligible"

    else:

        status = "Not Yet Eligible"

    # ========================================================
    # SKILL GAPS
    # ========================================================

    skill_gaps = []

    category_display_names = {

        "domain":
            "Ayurveda Domain Knowledge",

        "clinical":
            "Clinical & Patient Care",

        "pharmacy":
            "Ayurvedic Pharmacy",

        "research":
            "Research & Clinical Research",

        "public_health":
            "AYUSH & Public Health",

        "communication":
            "Communication",

        "soft_skills":
            "Teamwork & Professional Skills"
    }

    for category, stats in (
        category_stats.items()
    ):

        if stats["total"] == 0:

            continue

        score = round(

            (
                stats["correct"]
                /
                stats["total"]
            ) * 100,

            2
        )

        if score < 60:

            skill_gaps.append({

                "name":
                    category_display_names.get(

                        category,

                        category.replace(
                            "_",
                            " "
                        ).title()
                    ),

                "score":
                    score,

                "required":
                    60,

                "gap":
                    round(
                        60 - score,
                        2
                    )
            })

    # ========================================================
    # RESULT PAGE
    # ========================================================

    return render_template(

        "assessment_result.html",

        student=student,

        attempt=attempt,

        questions=[],

        category_stats=category_stats,

        percentage=percentage,

        correct_count=
            attempt.correct_answers,

        total_questions=
            attempt.total_questions,

        domain_score=domain_score,

        clinical_score=clinical_score,

        pharmacy_score=pharmacy_score,

        research_score=research_score,

        public_health_score=
            public_health_score,

        communication_score=
            communication_score,

        soft_skills_score=
            soft_skills_score,

        status=status,

        skill_gaps=skill_gaps,

        # ----------------------------------------------------
        # RE-ASSESSMENT DATA
        # ----------------------------------------------------

        previous_attempt=
            previous_attempt,

        previous_percentage=
            previous_percentage,

        improvement=
            improvement,

        is_reassessment=
            previous_attempt is not None
    )