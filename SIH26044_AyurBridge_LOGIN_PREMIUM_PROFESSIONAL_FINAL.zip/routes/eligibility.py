from flask import Blueprint, render_template, redirect, url_for, session
from models import Student, Internship, AssessmentAttempt

eligibility_bp = Blueprint("eligibility", __name__)


@eligibility_bp.route("/eligibility/<int:student_id>")
def check_eligibility(student_id):

    student = Student.query.get_or_404(student_id)

    latest_attempt = AssessmentAttempt.query.filter_by(
        student_id=student_id
    ).order_by(
        AssessmentAttempt.id.desc()
    ).first()

    if not latest_attempt:
        return redirect(
            url_for(
                "student.assessment",
                student_id=student_id
            )
        )

    assessment_score = latest_attempt.score_percentage or 0

    student_skills = set(student.skill_list())

    eligible = []
    partially_eligible = []
    not_eligible = []

    opportunities = Internship.query.all()

    for internship in opportunities:

        required_skills = set(
            internship.required_skill_list()
        )

        if required_skills:
            matched_skills = student_skills.intersection(
                required_skills
            )

            skill_match = (
                len(matched_skills) /
                len(required_skills)
            ) * 100
        else:
            skill_match = 100

        # Eligibility logic
        if assessment_score >= 75 and skill_match >= 70:
            status = "Eligible"
            eligible.append({
                "internship": internship,
                "skill_match": round(skill_match)
            })

        elif assessment_score >= 50 and skill_match >= 40:
            status = "Partially Eligible"
            partially_eligible.append({
                "internship": internship,
                "skill_match": round(skill_match)
            })

        else:
            status = "Not Eligible"
            not_eligible.append({
                "internship": internship,
                "skill_match": round(skill_match)
            })

    return render_template(
        "eligibility.html",
        student=student,
        assessment_score=round(assessment_score),
        eligible=eligible,
        partially_eligible=partially_eligible,
        not_eligible=not_eligible
    )