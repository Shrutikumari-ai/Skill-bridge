from flask import Blueprint, render_template, request, redirect, url_for

from models import db, Student, Company, Internship
from services import PlacementManager

placement_bp = Blueprint("placement", __name__)


# ============================================================
# PLACEMENT PAGE
# ============================================================

@placement_bp.route(
    "/placement/<int:student_id>",
    methods=["GET", "POST"]
)
def placement(student_id):

    student = Student.query.get_or_404(student_id)

    companies = Company.query.all()

    internships = Internship.query.all()


    # ========================================================
    # CREATE PLACEMENT
    # ========================================================

    if request.method == "POST":

        company_id = request.form.get("company_id")

        internship_id = request.form.get("internship_id")


        company = Company.query.get_or_404(company_id)


        internship = None

        if internship_id:

            internship = Internship.query.get(
                internship_id
            )


        placement_record = PlacementManager.create_placement(
            db,
            student,
            company,
            internship
        )


        return redirect(
            url_for(
                "placement.confirmation",
                placement_id=placement_record.id
            )
        )


    # ========================================================
    # DISPLAY PLACEMENT PAGE
    # ========================================================

    return render_template(
        "placement.html",
        student=student,
        companies=companies,
        internships=internships
    )


# ============================================================
# PLACEMENT CONFIRMATION
# ============================================================

@placement_bp.route(
    "/placement/confirmation/<int:placement_id>"
)
def confirmation(placement_id):

    from models import Placement


    placement_record = Placement.query.get_or_404(
        placement_id
    )


    return render_template(
        "placement_confirm.html",
        placement=placement_record
    )