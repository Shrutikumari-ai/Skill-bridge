from flask import Blueprint, render_template, redirect, url_for, request, flash

from models import (
    db,
    Student,
    AssessmentAttempt,
    AssessmentQuestion,
    LearningProgress
)

learning_bp = Blueprint("learning", __name__)


# =========================================================
# DEMO LEARNING RESOURCES
# =========================================================

LEARNING_RESOURCES = {

    "panchakarma": {
        "description": "Learn the basic concepts, principles and safety aspects of Panchakarma.",
        "videos": [
            {
                "title": "Panchakarma Basics",
                "description": "Introduction to the basic concepts of Panchakarma.",
                "url": "https://www.youtube.com/results?search_query=Panchakarma+Ayurveda+basics"
            }
        ],
        "courses": [
            {
                "title": "Ayurveda Fundamentals",
                "description": "Basic introduction to Ayurveda and related concepts.",
                "url": "https://www.coursesearch.com/"
            }
        ],
        "resources": [
            {
                "title": "Panchakarma Reference",
                "description": "Reference material for understanding Panchakarma.",
                "url": "https://www.google.com/search?q=Panchakarma+Ayurveda"
            }
        ]
    },

    "patient care": {
        "description": "Develop basic patient-care, communication and professionalism skills.",
        "videos": [
            {
                "title": "Patient Care Basics",
                "description": "Introduction to patient-care principles.",
                "url": "https://www.youtube.com/results?search_query=patient+care+basics"
            }
        ],
        "courses": [
            {
                "title": "Healthcare Communication",
                "description": "Learn the fundamentals of professional healthcare communication.",
                "url": "https://www.coursesearch.com/"
            }
        ],
        "resources": [
            {
                "title": "Patient Safety Reference",
                "description": "Basic patient safety and professionalism concepts.",
                "url": "https://www.google.com/search?q=patient+safety+basics"
            }
        ]
    },

    "formulation": {
        "description": "Learn the fundamentals of Ayurvedic formulations, ingredients and quality considerations.",
        "videos": [
            {
                "title": "Ayurvedic Formulation Basics",
                "description": "Introduction to formulation concepts.",
                "url": "https://www.youtube.com/results?search_query=Ayurvedic+formulation+basics"
            }
        ],
        "courses": [
            {
                "title": "Pharmaceutical Fundamentals",
                "description": "Basic pharmaceutical and formulation concepts.",
                "url": "https://www.coursesearch.com/"
            }
        ],
        "resources": [
            {
                "title": "Formulation Reference",
                "description": "Reference material for formulation principles.",
                "url": "https://www.google.com/search?q=Ayurvedic+formulation+principles"
            }
        ]
    },

    "research": {
        "description": "Build an understanding of research methodology, objectives and evidence-based thinking.",
        "videos": [
            {
                "title": "Research Methodology Basics",
                "description": "Introduction to research methodology.",
                "url": "https://www.youtube.com/results?search_query=research+methodology+basics"
            }
        ],
        "courses": [
            {
                "title": "Research Fundamentals",
                "description": "Learn basic research concepts and methods.",
                "url": "https://www.coursesearch.com/"
            }
        ],
        "resources": [
            {
                "title": "Research Methodology Reference",
                "description": "Reference material for understanding research methodology.",
                "url": "https://www.google.com/search?q=research+methodology+basics"
            }
        ]
    },

    "public health": {
        "description": "Learn community health, disease prevention and health-promotion fundamentals.",
        "videos": [
            {
                "title": "Public Health Basics",
                "description": "Introduction to public-health concepts.",
                "url": "https://www.youtube.com/results?search_query=public+health+basics"
            }
        ],
        "courses": [
            {
                "title": "Community Health Fundamentals",
                "description": "Basic concepts of community and public health.",
                "url": "https://www.coursesearch.com/"
            }
        ],
        "resources": [
            {
                "title": "Public Health Reference",
                "description": "Reference material for public-health concepts.",
                "url": "https://www.google.com/search?q=public+health+basics"
            }
        ]
    },

    "communication": {
        "description": "Improve professional communication, active listening and presentation skills.",
        "videos": [
            {
                "title": "Professional Communication",
                "description": "Learn the basics of professional communication.",
                "url": "https://www.youtube.com/results?search_query=professional+communication+skills"
            }
        ],
        "courses": [
            {
                "title": "Communication Skills",
                "description": "Build clear and effective communication skills.",
                "url": "https://www.coursesearch.com/"
            }
        ],
        "resources": [
            {
                "title": "Communication Reference",
                "description": "Reference material for communication skills.",
                "url": "https://www.google.com/search?q=professional+communication+skills"
            }
        ]
    },

    "soft skills": {
        "description": "Develop teamwork, problem solving, leadership and workplace professionalism.",
        "videos": [
            {
                "title": "Workplace Soft Skills",
                "description": "Introduction to essential workplace soft skills.",
                "url": "https://www.youtube.com/results?search_query=workplace+soft+skills"
            }
        ],
        "courses": [
            {
                "title": "Soft Skills Fundamentals",
                "description": "Learn important professional soft skills.",
                "url": "https://www.coursesearch.com/"
            }
        ],
        "resources": [
            {
                "title": "Soft Skills Reference",
                "description": "Reference material for workplace professionalism.",
                "url": "https://www.google.com/search?q=workplace+soft+skills"
            }
        ]
    },

    "technical": {
        "description": "Improve your technical knowledge and practical skills.",
        "videos": [],
        "courses": [],
        "resources": []
    },

    "domain": {
        "description": "Improve your domain-specific professional knowledge.",
        "videos": [],
        "courses": [],
        "resources": []
    },

    "aptitude": {
        "description": "Improve your aptitude and analytical ability.",
        "videos": [],
        "courses": [],
        "resources": []
    }
}


# =========================================================
# GET LEARNING RESOURCES
# =========================================================

def get_learning_resources(skill):

    skill_key = (skill or "").strip().lower()

    if skill_key in LEARNING_RESOURCES:
        return LEARNING_RESOURCES[skill_key]

    return {
        "description": f"Learn the fundamentals of {skill}.",
        "videos": [],
        "courses": [],
        "resources": []
    }


# =========================================================
# LEARNING HOME
# =========================================================

@learning_bp.route("/learning/<int:student_id>")
def learning_home(student_id):

    student = Student.query.get_or_404(student_id)

    # Latest assessment attempt
    attempt = (
        AssessmentAttempt.query
        .filter_by(student_id=student_id)
        .order_by(AssessmentAttempt.id.desc())
        .first()
    )

    # Existing learning progress
    progress_records = (
        LearningProgress.query
        .filter_by(student_id=student_id)
        .all()
    )

    # Quick lookup
    progress_map = {
        (record.skill or "").strip().lower(): record
        for record in progress_records
    }

    assessment_roadmap = []

    if attempt:

        categories = [
            ("technical", attempt.technical_score),
            ("domain", attempt.domain_score),
            ("problem_solving", attempt.problem_solving_score),
            ("aptitude", attempt.aptitude_score),
            ("communication", attempt.communication_score),
            ("soft_skills", attempt.soft_skills_score)
        ]

        skill_mapping = {
            "technical": "technical",
            "domain": "domain",
            "problem_solving": "problem solving",
            "aptitude": "aptitude",
            "communication": "communication",
            "soft_skills": "soft skills"
        }

        for category, score in categories:

            score = score or 0

            # Only show skills below 60%
            if score < 60:

                skill = skill_mapping.get(
                    category,
                    category
                )

                progress_record = progress_map.get(
                    skill.lower()
                )

                progress = 0
                completed = False

                if progress_record:
                    progress = progress_record.progress or 0
                    completed = progress_record.completed or False

                assessment_roadmap.append({
                    "skill": skill,
                    "score": round(score, 1),
                    "gap": round(60 - score, 1),
                    "progress": progress,
                    "completed": completed,
                    "learning_resources": get_learning_resources(skill)
                })

    return render_template(
        "learning.html",
        student=student,
        attempt=attempt,
        assessment_roadmap=assessment_roadmap,
        progress_records=progress_records
    )


# =========================================================
# START LEARNING
# =========================================================

@learning_bp.route(
    "/learning/<int:student_id>/start/<path:skill>"
)
def start_learning(student_id, skill):

    student = Student.query.get_or_404(student_id)

    progress_record = (
        LearningProgress.query
        .filter_by(
            student_id=student.id,
            skill=skill
        )
        .order_by(LearningProgress.id.desc())
        .first()
    )

    if not progress_record:

        progress_record = LearningProgress(
            student_id=student.id,
            skill=skill,
            progress=33,
            completed=False
        )

        db.session.add(progress_record)

    else:

        if progress_record.progress < 33:
            progress_record.progress = 33

        progress_record.completed = False

    db.session.commit()

    return redirect(
        url_for(
            "learning.learning_lesson",
            student_id=student.id,
            skill=skill
        )
    )


# =========================================================
# COMPLETE STEP 1 — LEARN
# =========================================================

@learning_bp.route(
    "/learning/<int:student_id>/complete-learn/<path:skill>"
)
def complete_learning(student_id, skill):

    student = Student.query.get_or_404(student_id)

    progress_record = (
        LearningProgress.query
        .filter_by(
            student_id=student.id,
            skill=skill
        )
        .order_by(LearningProgress.id.desc())
        .first()
    )

    if not progress_record:

        flash(
            "Please start learning first.",
            "warning"
        )

        return redirect(
            url_for(
                "learning.learning_home",
                student_id=student.id
            )
        )

    # 65% = Step 1 completed
    # Practice becomes unlocked
    if progress_record.progress < 65:

        progress_record.progress = 65
        progress_record.completed = False

        db.session.commit()

    flash(
        "Step 1 completed! Step 2 — Practice is now unlocked.",
        "success"
    )

    return redirect(
        url_for(
            "learning.learning_lesson",
            student_id=student.id,
            skill=skill
        )
    )


# =========================================================
# LESSON PAGE
# =========================================================

@learning_bp.route(
    "/learning/<int:student_id>/lesson/<path:skill>"
)
def learning_lesson(student_id, skill):

    student = Student.query.get_or_404(student_id)

    progress_record = (
        LearningProgress.query
        .filter_by(
            student_id=student.id,
            skill=skill
        )
        .order_by(LearningProgress.id.desc())
        .first()
    )

    progress = 0
    completed = False

    if progress_record:

        progress = progress_record.progress or 0
        completed = progress_record.completed or False

    return render_template(
        "learning_lesson.html",
        student=student,
        skill=skill,
        progress=progress,
        completed=completed,
        progress_record=progress_record,
        learning_resources=get_learning_resources(skill)
    )


# =========================================================
# PRACTICE
# =========================================================

@learning_bp.route(
    "/learning/<int:student_id>/practice/<path:skill>",
    methods=["GET", "POST"]
)
def practice_learning(student_id, skill):

    student = Student.query.get_or_404(student_id)

    progress_record = (
        LearningProgress.query
        .filter_by(
            student_id=student.id,
            skill=skill
        )
        .order_by(LearningProgress.id.desc())
        .first()
    )

    # -----------------------------------------------------
    # Practice Lock
    # -----------------------------------------------------

    if (
        not progress_record
        or progress_record.progress < 65
    ):

        flash(
            "Complete Step 1 — Learn before starting Practice.",
            "warning"
        )

        return redirect(
            url_for(
                "learning.learning_lesson",
                student_id=student.id,
                skill=skill
            )
        )

    # -----------------------------------------------------
    # Questions
    # -----------------------------------------------------

    questions = (
        AssessmentQuestion.query
        .filter(
            AssessmentQuestion.career_field.ilike(
                f"%{skill}%"
            )
        )
        .limit(5)
        .all()
    )

    # Fallback questions
    if not questions:

        questions = (
            AssessmentQuestion.query
            .limit(5)
            .all()
        )

    # -----------------------------------------------------
    # GET
    # -----------------------------------------------------

    if request.method == "GET":

        return render_template(
            "learning_practice.html",
            student=student,
            skill=skill,
            questions=questions,
            progress=progress_record.progress
        )

    # -----------------------------------------------------
    # POST
    # -----------------------------------------------------

    correct = 0
    total = len(questions)

    for question in questions:

        selected_answer = request.form.get(
            f"question_{question.id}"
        )

        if (
            selected_answer
            and selected_answer.upper()
            == question.correct_answer.upper()
        ):
            correct += 1

    # -----------------------------------------------------
    # Calculate score
    # -----------------------------------------------------

    score = 0

    if total > 0:
        score = (correct / total) * 100

    # -----------------------------------------------------
    # Practice PASS
    # -----------------------------------------------------

    if score >= 60:

        # 66% = Practice passed
        progress_record.progress = 66
        progress_record.completed = False

        db.session.commit()

        flash(
            "Practice passed! Re-Assessment is now unlocked.",
            "success"
        )

    # -----------------------------------------------------
    # Practice FAIL
    # -----------------------------------------------------

    else:

        # Keep Practice unlocked
        progress_record.progress = 65
        progress_record.completed = False

        db.session.commit()

        flash(
            "Practice score is below 60%. Please practice again.",
            "warning"
        )

    return redirect(
        url_for(
            "learning.learning_home",
            student_id=student.id
        )
    )


# =========================================================
# APPLY
# =========================================================

@learning_bp.route(
    "/learning/<int:student_id>/apply/<path:skill>"
)
def apply_learning(student_id, skill):

    student = Student.query.get_or_404(student_id)

    progress_record = (
        LearningProgress.query
        .filter_by(
            student_id=student.id,
            skill=skill
        )
        .order_by(LearningProgress.id.desc())
        .first()
    )

    # Apply is locked before Practice
    if (
        not progress_record
        or progress_record.progress < 66
    ):

        flash(
            "Complete Step 2 — Practice before applying.",
            "warning"
        )

        return redirect(
            url_for(
                "learning.learning_home",
                student_id=student.id
            )
        )

    # Complete skill
    progress_record.progress = 100
    progress_record.completed = True

    db.session.commit()

    flash(
        "Skill completed successfully!",
        "success"
    )

    return redirect(
        url_for(
            "learning.learning_home",
            student_id=student.id
        )
    )


# =========================================================
# RESET LEARNING
# =========================================================

@learning_bp.route(
    "/learning/<int:student_id>/reset/<path:skill>"
)
def reset_learning(student_id, skill):

    student = Student.query.get_or_404(student_id)

    progress_record = (
        LearningProgress.query
        .filter_by(
            student_id=student.id,
            skill=skill
        )
        .order_by(LearningProgress.id.desc())
        .first()
    )

    if progress_record:

        progress_record.progress = 0
        progress_record.completed = False

        db.session.commit()

    flash(
        "Learning progress has been reset.",
        "info"
    )

    return redirect(
        url_for(
            "learning.learning_home",
            student_id=student.id
        )
    )

