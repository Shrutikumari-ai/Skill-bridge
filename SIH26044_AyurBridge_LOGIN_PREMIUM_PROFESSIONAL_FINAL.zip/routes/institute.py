from flask import Blueprint, render_template, request, redirect, url_for, flash, send_from_directory
from sqlalchemy import or_, func
from datetime import date
from pathlib import Path
from werkzeug.utils import secure_filename
import uuid

from models import (
    db,
    Student,
    AssessmentAttempt,
    AssessmentAnswer,
    AssessmentQuestion,
    Application,
    Internship,
    Placement,
    LearningProgress,
    Company,
    Organization,
    IndustrySkillDemand, SkillGapRecord, LearningRecommendation,
    InternshipProgress, MentorFeedback, InternshipCompletion,
    StudentPortfolio, PortfolioVerification, PlacementReadiness, SkillMatch,
    CareerGuidance, IndustryWorkshop, GuestLecture, LiveIndustryProject,
    ResearchCollaboration, SecureDocument, RolePermission,
    IndustryJob, JobApplication, FacultyProgram, IndustryTraining, TrainingParticipation,
    Notification, InnovationChallenge, ChallengeSubmission, SecureDocumentFile,
)

institute_bp = Blueprint("institute", __name__, url_prefix="/institute")


@institute_bp.route("/dashboard")
def dashboard():
    # Refresh the SIH intelligence layer so Skill Gap → Learning →
    # Re-assessment signals stay personalized on every institute visit.
    _upsert_demo_advanced_data()
    # Reuse the same data-driven dashboard used by the Academia view,
    # but keep the Institute URL so the institute portal is independent.
    students = Student.query.order_by(Student.id.desc()).all()
    assessments = AssessmentAttempt.query.all()
    internships = Internship.query.all()
    applications = Application.query.all()
    placements = Placement.query.all()
    learning_progress = LearningProgress.query.all()

    total_students = len(students)
    total_assessments = len(assessments)
    total_internships = len(internships)
    total_applications = len(applications)
    total_placements = len(placements)

    average_score = round(
        sum(a.score_percentage or 0 for a in assessments) / len(assessments), 2
    ) if assessments else 0

    placement_rate = round(
        (total_placements / total_students) * 100, 2
    ) if total_students else 0

    student_rows = []
    for student in students[:8]:
        latest_attempt = (
            AssessmentAttempt.query
            .filter_by(student_id=student.id)
            .order_by(AssessmentAttempt.id.desc())
            .first()
        )
        score = round(latest_attempt.score_percentage or 0, 2) if latest_attempt else 0
        if score >= 75:
            readiness = "Highly Ready"
        elif score >= 60:
            readiness = "Ready"
        elif score >= 40:
            readiness = "Needs Improvement"
        elif latest_attempt:
            readiness = "Needs Development"
        else:
            readiness = "Assessment Pending"
        student_rows.append({"student": student, "score": score, "readiness": readiness})

    ayurveda_map = [
        ("Panchakarma", "domain_score"),
        ("Ayurvedic Formulation", "domain_score"),
        ("Clinical Research", "technical_score"),
        ("Patient Counselling", "communication_score"),
        ("Clinical Documentation", "soft_skills_score"),
        ("Medicinal Plant Identification", "domain_score"),
    ]
    skill_gap_data = []
    for name, field in ayurveda_map:
        scores = [getattr(a, field, 0) or 0 for a in assessments]
        average = round(sum(scores) / len(scores), 2) if scores else 0
        target = 80
        skill_gap_data.append({"name": name, "score": average, "gap": round(max(0, target - average), 2)})
    skill_gap_data.sort(key=lambda item: item["gap"], reverse=True)

    recent_internships = Internship.query.order_by(Internship.id.desc()).limit(5).all()
    recent_placements = Placement.query.order_by(Placement.id.desc()).limit(5).all()
    completed_learning = sum(1 for item in learning_progress if item.completed)

    # SIH-focused readiness summary. Keep this dashboard read-only: it derives
    # the categories from the latest assessment instead of mutating the DB.
    readiness_summary = {
        "Highly Ready": 0,
        "Ready": 0,
        "Needs Improvement": 0,
        "Needs Development": 0,
        "Assessment Pending": 0,
    }
    for row in student_rows:
        readiness_summary[row["readiness"]] += 1

    # Industry-vs-student comparison. Industry demand is taken only from the
    # institute's stored demand records; no invented demand values are used.
    demand_rows = IndustrySkillDemand.query.order_by(IndustrySkillDemand.required_count.desc()).limit(6).all()
    demand_comparison = []
    for demand in demand_rows:
        matching = next((x for x in skill_gap_data
                         if x["name"].lower() in demand.skill.lower()
                         or demand.skill.lower() in x["name"].lower()), None)
        student_score = matching["score"] if matching else 0
        demand_levels = {"High": 85, "Medium": 70, "Low": 50}
        target = demand_levels.get((demand.demand_level or "Medium").title(), 70)
        demand_comparison.append({
            "skill": demand.skill,
            "demand_level": demand.demand_level or "Medium",
            "industry_need": round(target, 1),
            "student_score": round(student_score, 1),
            "gap": round(max(0, target - student_score), 1),
        })

    # The dashboard's action cards point the institute team toward the most
    # useful next actions based on the largest observed skill gaps.
    priority_actions = []
    for item in skill_gap_data[:3]:
        if item["gap"] > 0:
            priority_actions.append({
                "title": f"{item['name']} development",
                "detail": f"Average skill level is {item['score']}%, leaving a {item['gap']} point gap to the 80% target.",
                "url": url_for("institute.learning_recommendations"),
            })

    # Personalized learning is the primary intervention layer: show the
    # highest-priority current recommendations directly on the dashboard.
    learning_recommendation_rows = (
        LearningRecommendation.query.join(Student)
        .order_by(LearningRecommendation.id.desc())
        .limit(6).all()
    )
    learning_recommendation_count = LearningRecommendation.query.filter_by(status="Recommended").count()

    return render_template("institute/institute_dashboard.html",
        students=students,
        student_rows=student_rows,
        total_students=total_students,
        total_assessments=total_assessments,
        total_internships=total_internships,
        total_applications=total_applications,
        total_placements=total_placements,
        average_score=average_score,
        placement_rate=placement_rate,
        skill_gap_data=skill_gap_data,
        recent_internships=recent_internships,
        recent_placements=recent_placements,
        completed_learning=completed_learning,
        readiness_summary=readiness_summary,
        demand_comparison=demand_comparison,
        priority_actions=priority_actions,
        learning_recommendation_rows=learning_recommendation_rows,
        learning_recommendation_count=learning_recommendation_count,
        institute_mode=True,
    )


@institute_bp.route("/students")
def students():
    search = request.args.get("search", "").strip()
    degree = request.args.get("degree", "").strip()
    query = Student.query
    if search:
        query = query.filter(or_(Student.name.ilike(f"%{search}%")))
    if degree:
        query = query.filter(Student.degree.ilike(f"%{degree}%"))

    student_list = query.order_by(Student.id.desc()).all()
    rows = []
    for student in student_list:
        assessment = (
            AssessmentAttempt.query
            .filter_by(student_id=student.id)
            .order_by(AssessmentAttempt.id.desc())
            .first()
        )
        rows.append({
            "student": student,
            "assessment": assessment,
            "applications": Application.query.filter_by(student_id=student.id).count(),
            "placement": Placement.query.filter_by(student_id=student.id).first(),
        })
    return render_template("institute/institute_students.html", students=rows, search=search, degree=degree)


@institute_bp.route("/students/<int:student_id>")
def student_detail(student_id):
    student = Student.query.get_or_404(student_id)
    assessments = AssessmentAttempt.query.filter_by(student_id=student.id).order_by(AssessmentAttempt.id.desc()).all()
    applications = Application.query.filter_by(student_id=student.id).order_by(Application.id.desc()).all()
    placements = Placement.query.filter_by(student_id=student.id).order_by(Placement.id.desc()).all()
    learning = LearningProgress.query.filter_by(student_id=student.id).order_by(LearningProgress.id.desc()).all()
    return render_template("institute/institute_student_detail.html",
        student=student,
        assessments=assessments,
        applications=applications,
        placements=placements,
        learning=learning,
    )


@institute_bp.route("/analytics")
def analytics():
    assessments = AssessmentAttempt.query.all()
    students = Student.query.all()
    categories = {
        "technical_score": "Technical Skills",
        "domain_score": "Domain Knowledge",
        "problem_solving_score": "Problem Solving",
        "aptitude_score": "Aptitude",
        "communication_score": "Communication",
        "soft_skills_score": "Soft Skills",
    }
    skill_averages = []
    for field, name in categories.items():
        values = [getattr(a, field, 0) or 0 for a in assessments]
        skill_averages.append({"name": name, "score": round(sum(values) / len(values), 2) if values else 0})

    readiness = {"Highly Ready": 0, "Ready": 0, "Needs Improvement": 0, "Needs Development": 0, "Assessment Pending": 0}
    for student in students:
        attempt = AssessmentAttempt.query.filter_by(student_id=student.id).order_by(AssessmentAttempt.id.desc()).first()
        score = attempt.score_percentage or 0 if attempt else 0
        if not attempt:
            label = "Assessment Pending"
        elif score >= 75:
            label = "Highly Ready"
        elif score >= 60:
            label = "Ready"
        elif score >= 40:
            label = "Needs Improvement"
        else:
            label = "Needs Development"
        readiness[label] += 1

    return render_template("institute/institute_analytics.html",
        total_assessments=len(assessments),
        total_students=len(students),
        average_score=round(sum(a.score_percentage or 0 for a in assessments) / len(assessments), 2) if assessments else 0,
        skill_averages=skill_averages,
        readiness=readiness,
    )


@institute_bp.route("/assessments")
def assessments():
    attempts = (
        AssessmentAttempt.query
        .order_by(AssessmentAttempt.id.desc())
        .all()
    )
    return render_template("institute/institute_assessments.html", assessments=attempts)


@institute_bp.route("/internships", methods=["GET", "POST"])
def internships():
    if request.method == "POST":
        field = request.form.get("field", "").strip()
        if not field:
            flash("Opportunity field is required.", "warning")
            return redirect(url_for("institute.internships"))
        opportunity = Internship(
            field=field,
            department=request.form.get("department", "").strip(),
            sector=request.form.get("sector", "").strip(),
            required_degree=request.form.get("required_degree", "").strip(),
            required_skills=", ".join(request.form.getlist("required_skills")),
            city=request.form.get("city", "").strip(),
            state=request.form.get("state", "").strip(),
            duration=request.form.get("duration", "").strip(),
            description=request.form.get("description", "").strip(),
            apply_link=request.form.get("apply_link", "").strip(),
        )
        db.session.add(opportunity)
        db.session.commit()
        flash("Internship opportunity created successfully.", "success")
        return redirect(url_for("institute.internships"))

    items = Internship.query.order_by(Internship.id.desc()).all()
    return render_template("institute/institute_internships.html", internships=items)


@institute_bp.route("/applications", methods=["GET", "POST"])
def applications():
    if request.method == "POST":
        application_id = request.form.get("application_id", type=int)
        status = request.form.get("status", "Applied").strip()
        application = Application.query.get_or_404(application_id)
        application.status = status
        db.session.commit()
        flash("Application status updated.", "success")
        return redirect(url_for("institute.applications"))

    items = Application.query.order_by(Application.applied_at.desc()).all()
    return render_template("institute/institute_applications.html", applications=items)


@institute_bp.route("/placements", methods=["GET", "POST"])
def placements():
    if request.method == "POST":
        student_id = request.form.get("student_id", type=int)
        company_id = request.form.get("company_id", type=int)
        internship_id = request.form.get("internship_id", type=int) or None
        if not student_id or not company_id:
            flash("Student and company are required.", "warning")
            return redirect(url_for("institute.placements"))
        db.session.add(Placement(
            student_id=student_id,
            company_id=company_id,
            internship_id=internship_id,
            status=request.form.get("status", "placed").strip() or "placed",
        ))
        db.session.commit()
        flash("Placement record created successfully.", "success")
        return redirect(url_for("institute.placements"))

    items = Placement.query.order_by(Placement.id.desc()).all()
    return render_template("institute/institute_placements.html",
        placements=items,
        students=Student.query.order_by(Student.name).all(),
        companies=Company.query.order_by(Company.name).all(),
        internships=Internship.query.order_by(Internship.field).all(),
    )


@institute_bp.route("/training")
def training():
    students = Student.query.order_by(Student.name).all()
    progress = LearningProgress.query.order_by(LearningProgress.id.desc()).all()
    return render_template("institute/institute_training.html", students=students, progress=progress)


@institute_bp.route("/collaboration")
def collaboration():
    return render_template("institute/institute_collaboration.html",
        companies=Company.query.order_by(Company.name).all(),
        organizations=Organization.query.order_by(Organization.name).all(),
    )


@institute_bp.route("/reports")
def reports():
    total_students = Student.query.count()
    total_assessments = AssessmentAttempt.query.count()
    total_applications = Application.query.count()
    total_placements = Placement.query.count()
    total_internships = Internship.query.count()
    return render_template("institute/institute_reports.html",
        total_students=total_students,
        total_assessments=total_assessments,
        total_applications=total_applications,
        total_placements=total_placements,
        total_internships=total_internships,
    )


# =========================================================
# SIH26044 ADVANCED INSTITUTE FEATURES
# =========================================================

def _skill_profile(student):
    """Build an institute-side skill profile from the latest assessment + declared skills."""
    attempt = (AssessmentAttempt.query.filter_by(student_id=student.id)
               .order_by(AssessmentAttempt.id.desc()).first())
    declared = {s.strip().lower() for s in (student.skills or "").split(",") if s.strip()}
    specialization = (student.specialization or "").strip().lower()

    technical = float((getattr(attempt, "technical_score", 0) if attempt else 0) or 0)
    domain = float((getattr(attempt, "domain_score", 0) if attempt else 0) or 0)
    communication = float((getattr(attempt, "communication_score", 0) if attempt else 0) or 0)
    soft = float((getattr(attempt, "soft_skills_score", 0) if attempt else 0) or 0)

    skill_base = {
        "Panchakarma": domain,
        "Patient Care": domain,
        "Ayurvedic Formulation": domain,
        "Clinical Research": technical,
        "Pharmacovigilance": technical,
        "Communication": communication,
        "Patient Counselling": communication,
        "Clinical Documentation": soft,
        "Team Collaboration": soft,
        "Professional Behaviour": soft,
        "Medicinal Plant Identification": domain,
        "Dravyaguna": domain,
        "Rasashastra & Bhaishajya Kalpana": domain,
        "Kayachikitsa": domain,
        "Shalya Chikitsa": domain,
        "Shalakya Tantra": domain,
        "Prasuti & Stri Roga": domain,
        "Kaumarbhritya": domain,
        "Swasthavritta": domain,
        "Yoga & Lifestyle Management": domain,
    }
    result=[]
    for skill, score in skill_base.items():
        low=skill.lower()
        current=float(score or 0)
        if low in declared or low.replace(" & ", " ") in declared:
            current=max(current, 70.0)
        if specialization and (low in specialization or specialization in low):
            current=max(current, 80.0)
        result.append({"skill": skill, "score": round(min(100, current), 1)})
    return result


ROLE_PROFILES = {
    "Panchakarma Therapist": {
        "Panchakarma": 80, "Patient Care": 75, "Patient Counselling": 70, "Clinical Documentation": 65
    },
    "Ayurvedic Clinical Officer": {
        "Patient Care": 80, "Panchakarma": 75, "Communication": 75, "Clinical Documentation": 70
    },
    "Ayurvedic Formulation Specialist": {
        "Ayurvedic Formulation": 80, "Rasashastra & Bhaishajya Kalpana": 75,
        "Medicinal Plant Identification": 65, "Clinical Documentation": 60
    },
    "Clinical Research Associate": {
        "Clinical Research": 80, "Clinical Documentation": 70, "Communication": 70, "Pharmacovigilance": 65
    },
    "Wellness Consultant": {
        "Patient Counselling": 80, "Communication": 75, "Swasthavritta": 70, "Patient Care": 60
    },
}


def _role_for_student(student):
    text=" ".join([student.specialization or "", student.desired_field or "", student.skills or ""]).lower()
    if "panchakarma" in text:
        return "Panchakarma Therapist"
    if "rasashastra" in text or "formulation" in text:
        return "Ayurvedic Formulation Specialist"
    if "research" in text:
        return "Clinical Research Associate"
    if "swasthavritta" in text or "wellness" in text:
        return "Wellness Consultant"
    return "Ayurvedic Clinical Officer"


def _profile_dict(student):
    return {x["skill"].lower(): x["score"] for x in _skill_profile(student)}


def _match_skills(student, required_skills):
    profile=_profile_dict(student)
    required=[s.strip() for s in (required_skills or "").split(",") if s.strip()]
    matched=[]
    missing=[]
    total=0.0
    aliases={
        "rasashastra": "rasashastra & bhaishajya kalpana",
        "bhaishajya kalpana": "rasashastra & bhaishajya kalpana",
        "communication skills": "communication",
    }
    for skill in required:
        key=skill.lower()
        key=aliases.get(key, key)
        score=profile.get(key, 0.0)
        required_level=70.0
        total += min(score / required_level, 1.0)
        if score >= required_level:
            matched.append(f"{skill} ({score:.0f}%)")
        else:
            missing.append(f"{skill} ({score:.0f}% / {required_level:.0f}%)")
    percentage=round((total / len(required))*100, 1) if required else 0.0
    return percentage, matched, missing


def _upsert_demo_advanced_data():
    """Refresh institute-side intelligence without changing unrelated records."""
    students=Student.query.all()
    for student in students:
        profile=_profile_dict(student)
        role=_role_for_student(student)
        req=ROLE_PROFILES[role]
        missing=[skill for skill, target in req.items() if profile.get(skill.lower(), 0) < target]
        readiness=round(sum(min(profile.get(skill.lower(), 0), target) / target * 100 for skill,target in req.items()) / len(req), 1)
        gap=round(100-readiness, 1)
        current=", ".join(f"{skill} {profile.get(skill.lower(), 0):.0f}%" for skill in req)
        row=SkillGapRecord.query.filter_by(student_id=student.id).first()
        if not row:
            row=SkillGapRecord(student_id=student.id)
            db.session.add(row)
        row.target_role=role
        row.required_skills=", ".join(f"{k} ({v}%)" for k,v in req.items())
        row.current_skills=current
        row.missing_skills=", ".join(missing) or "None — maintain and re-assess"
        row.gap_percentage=gap
        row.readiness_percentage=readiness

        attempt=(AssessmentAttempt.query.filter_by(student_id=student.id).order_by(AssessmentAttempt.id.desc()).first())
        technical=float((getattr(attempt,"technical_score",0) if attempt else 0) or 0)
        domain=float((getattr(attempt,"domain_score",0) if attempt else 0) or 0)
        communication=float((getattr(attempt,"communication_score",0) if attempt else 0) or 0)
        soft=float((getattr(attempt,"soft_skills_score",0) if attempt else 0) or 0)
        internship=100.0 if InternshipProgress.query.filter_by(student_id=student.id).filter(InternshipProgress.status.in_(["Started","In Progress","Completed"])).first() else 40.0
        role_match, _, _ = _match_skills(student, ",".join(req.keys()))
        overall=round(technical*0.20 + domain*0.20 + communication*0.15 + soft*0.15 + internship*0.10 + readiness*0.10 + role_match*0.10, 1)
        label="Placement Ready" if overall>=80 else "Almost Ready" if overall>=65 else "Needs Training"
        pr=PlacementReadiness.query.filter_by(student_id=student.id).first()
        if not pr:
            pr=PlacementReadiness(student_id=student.id)
            db.session.add(pr)
        pr.target_role=role
        pr.technical_score=round(technical,1)
        pr.domain_score=round(domain,1)
        pr.communication_score=round(communication,1)
        pr.soft_skill_score=round(soft,1)
        pr.internship_score=internship
        pr.overall_readiness=overall
        pr.readiness_label=label
        pr.required_skills=", ".join(req.keys())
        pr.current_skills=current

        for skill in missing[:3]:
            existing=(LearningRecommendation.query.filter_by(student_id=student.id, skill=skill).first())
            titles={
                "Panchakarma":"Panchakarma Clinical Skills Practice",
                "Patient Care":"Patient Care & Clinical Handling Training",
                "Patient Counselling":"Patient Counselling Workshop",
                "Clinical Documentation":"Clinical Documentation Workshop",
                "Communication":"Professional Communication Workshop",
                "Ayurvedic Formulation":"Ayurvedic Formulation & Quality Training",
                "Rasashastra & Bhaishajya Kalpana":"Rasashastra & Bhaishajya Kalpana Training",
                "Medicinal Plant Identification":"Medicinal Plant Identification Field Training",
                "Clinical Research":"Clinical Research Methods Training",
                "Pharmacovigilance":"Ayurveda Pharmacovigilance Training",
                "Swasthavritta":"Swasthavritta & Preventive Health Training",
            }
            rec=existing or LearningRecommendation(student_id=student.id, skill=skill)
            if existing is None:
                db.session.add(rec)
            rec.recommendation_type="Skill-gap Training"
            rec.title=titles.get(skill, f"{skill} Skill Development Program")
            rec.roadmap=f"Skill Gap → {rec.title} → Guided Practice → Internship / Project → Mentor Feedback → Re-assessment"
            rec.status="Recommended"

        # Keep existing manual/seeded recommendations intact; only auto-refresh the ones linked to current gaps.

        opportunities=[]
        for internship in Internship.query.order_by(Internship.id).all():
            pct,matched,missing_skills=_match_skills(student, internship.required_skills)
            opportunities.append((pct, internship.field, internship.department or internship.sector or "Industry", ", ".join(matched) or "None", ", ".join(missing_skills) or "None", f"Build {missing_skills[0].split(' (')[0]} first." if missing_skills else "Ready for this skill profile."))
        for job in IndustryJob.query.order_by(IndustryJob.id).all():
            pct,matched,missing_skills=_match_skills(student, job.required_skills)
            opportunities.append((pct, job.title, job.company, ", ".join(matched) or "None", ", ".join(missing_skills) or "None", f"Build {missing_skills[0].split(' (')[0]} first." if missing_skills else "Ready for this role's skill profile."))
        for pct,job_role,industry,matched,missing_skills,improvement in sorted(opportunities, reverse=True)[:5]:
            match=SkillMatch.query.filter_by(student_id=student.id, job_role=job_role, industry=industry).first()
            if not match:
                match=SkillMatch(student_id=student.id, job_role=job_role, industry=industry)
                db.session.add(match)
            match.match_percentage=pct
            match.matched_skills=matched
            match.missing_skills=missing_skills
            match.recommended_improvement=improvement

    db.session.commit()


@institute_bp.route("/skill-demand", methods=["GET","POST"])
def skill_demand():
    if request.method == "POST":
        db.session.add(IndustrySkillDemand(
            skill=request.form.get("skill"), domain=request.form.get("domain"),
            demand_level=request.form.get("demand_level","Medium"),
            required_count=int(request.form.get("required_count") or 0),
            industry_count=int(request.form.get("industry_count") or 0),
            description=request.form.get("description")
        ))
        db.session.commit()
        flash("Industry skill demand added.", "success")
        return redirect(url_for("institute.skill_demand"))
    demands=IndustrySkillDemand.query.order_by(IndustrySkillDemand.required_count.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="skill_demand", title="Industry Skill Demand", demands=demands)


@institute_bp.route("/skill-gap")
def skill_gap():
    _upsert_demo_advanced_data()
    rows=SkillGapRecord.query.join(Student).order_by(SkillGapRecord.gap_percentage.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="skill_gap", title="Industry → Student Skill Gap", gap_rows=rows)


@institute_bp.route("/learning-recommendations")
def learning_recommendations():
    _upsert_demo_advanced_data()
    rows=LearningRecommendation.query.join(Student).order_by(LearningRecommendation.id.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="recommendations", title="Personalized Learning Recommendation", recommendations=rows)


@institute_bp.route("/internship-progress", methods=["GET","POST"])
def internship_progress():
    if request.method=="POST":
        db.session.add(InternshipProgress(
            student_id=int(request.form["student_id"]), internship_id=int(request.form["internship_id"]),
            status=request.form.get("status","Applied"), progress_percentage=float(request.form.get("progress") or 0),
            milestones=request.form.get("milestones"), tasks=request.form.get("tasks")
        ))
        db.session.commit()
        flash("Internship progress updated.", "success")
        return redirect(url_for("institute.internship_progress"))
    rows=InternshipProgress.query.order_by(InternshipProgress.id.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="internship_progress", title="Internship Progress Tracking",
                           progress_rows=rows, students=Student.query.all(), internships=Internship.query.all())


@institute_bp.route("/mentor-feedback", methods=["GET","POST"])
def mentor_feedback():
    if request.method=="POST":
        db.session.add(MentorFeedback(
            student_id=int(request.form["student_id"]), internship_id=int(request.form["internship_id"]) if request.form.get("internship_id") else None,
            mentor_name=request.form["mentor_name"], mentor_organization=request.form.get("mentor_organization"),
            clinical_skill=float(request.form.get("clinical_skill") or 0), patient_handling=float(request.form.get("patient_handling") or 0),
            ayurveda_knowledge=float(request.form.get("ayurveda_knowledge") or 0), communication=float(request.form.get("communication") or 0),
            professional_behaviour=float(request.form.get("professional_behaviour") or 0), overall_rating=float(request.form.get("overall_rating") or 0),
            comments=request.form.get("comments")
        ))
        db.session.commit()
        flash("Mentor feedback saved.", "success")
        return redirect(url_for("institute.mentor_feedback"))
    rows=MentorFeedback.query.order_by(MentorFeedback.id.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="mentor_feedback", title="Mentor Feedback",
                           feedback_rows=rows, students=Student.query.all(), internships=Internship.query.all())


@institute_bp.route("/completion-records", methods=["GET","POST"])
def completion_records():
    if request.method=="POST":
        db.session.add(InternshipCompletion(
            student_id=int(request.form["student_id"]), internship_id=int(request.form["internship_id"]),
            completion_status=request.form.get("status","Completed"), duration=request.form.get("duration"),
            mentor=request.form.get("mentor"), skills_acquired=request.form.get("skills_acquired"),
            final_rating=float(request.form.get("final_rating") or 0), certificate=request.form.get("certificate")
        ))
        db.session.commit()
        flash("Internship completion record saved.", "success")
        return redirect(url_for("institute.completion_records"))
    rows=InternshipCompletion.query.order_by(InternshipCompletion.id.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="completion", title="Internship Completion Record",
                           completion_rows=rows, students=Student.query.all(), internships=Internship.query.all())


@institute_bp.route("/portfolio")
def portfolio():
    rows=StudentPortfolio.query.join(Student).order_by(Student.name).all()
    return render_template("institute/institute_sih_features.html", feature="portfolio", title="Digital Student Portfolio", portfolio_rows=rows)


@institute_bp.route("/portfolio/<int:student_id>")
def student_portfolio(student_id):
    student=Student.query.get_or_404(student_id)
    portfolio=StudentPortfolio.query.filter_by(student_id=student_id).first()
    if portfolio:
        # Give every important portfolio section an explicit institute-verification state.
        if PortfolioVerification.query.filter_by(portfolio_id=portfolio.id).count() == 0:
            artifacts = [
                ("Skills Profile", "Skills"), ("Certifications", "Certificate"),
                ("Internship Evidence", "Internship"), ("Projects", "Project"),
                ("Achievements", "Achievement"), ("Research / Publications", "Publication"),
            ]
            db.session.add_all([PortfolioVerification(portfolio_id=portfolio.id, document_name=name, document_type=kind) for name,kind in artifacts])
            db.session.commit()
    verifications=PortfolioVerification.query.filter_by(portfolio_id=portfolio.id).all() if portfolio else []
    documents=SecureDocumentFile.query.filter_by(student_id=student_id).order_by(SecureDocumentFile.id.desc()).all()
    learning_rows=LearningRecommendation.query.filter_by(student_id=student_id, status="Recommended").order_by(LearningRecommendation.id.desc()).limit(3).all()
    return render_template("institute/institute_sih_features.html", feature="portfolio_detail", title=f"{student.name} — Digital Portfolio",
                           portfolio=portfolio, student=student, verifications=verifications, documents=documents, learning_rows=learning_rows)


@institute_bp.route("/portfolio/verify/<int:portfolio_id>", methods=["POST"])
def verify_portfolio(portfolio_id):
    portfolio=StudentPortfolio.query.get_or_404(portfolio_id)
    status=request.form.get("status", "Verified")
    portfolio.verification_status=status
    portfolio.institute_verified=(status == "Verified")
    db.session.commit()
    flash("Portfolio verification status updated.", "success")
    return redirect(url_for("institute.student_portfolio", student_id=portfolio.student_id))


@institute_bp.route("/portfolio/verify-item/<int:verification_id>", methods=["POST"])
def verify_portfolio_item(verification_id):
    item=PortfolioVerification.query.get_or_404(verification_id)
    item.status=request.form.get("status", "Verified")
    item.verified_by=request.form.get("verified_by", "Institute")
    item.remarks=request.form.get("remarks")
    db.session.commit()

    portfolio=item.portfolio
    if portfolio:
        items=PortfolioVerification.query.filter_by(portfolio_id=portfolio.id).all()
        if items and all(x.status == "Verified" for x in items):
            portfolio.verification_status="Verified"
            portfolio.institute_verified=True
        elif any(x.status == "Rejected" for x in items):
            portfolio.verification_status="Needs Review"
            portfolio.institute_verified=False
        else:
            portfolio.verification_status="Pending Verification"
            portfolio.institute_verified=False
        db.session.commit()
    flash("Portfolio item verification updated.", "success")
    return redirect(url_for("institute.student_portfolio", student_id=portfolio.student_id))


@institute_bp.route("/placement-readiness")
def placement_readiness():
    _upsert_demo_advanced_data()
    rows=PlacementReadiness.query.join(Student).order_by(PlacementReadiness.overall_readiness.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="readiness", title="Industry-specific Placement Readiness", readiness_rows=rows)


@institute_bp.route("/skill-matching")
def skill_matching():
    _upsert_demo_advanced_data()
    rows=SkillMatch.query.join(Student).order_by(SkillMatch.match_percentage.desc()).all()
    return render_template("institute/institute_sih_features.html", feature="matching", title="Advanced Student–Industry Skill Matching", match_rows=rows)


@institute_bp.route("/demand-analytics")
def demand_analytics():
    demands=IndustrySkillDemand.query.all()
    by_domain={}
    for d in demands:
        by_domain[d.domain]=by_domain.get(d.domain,0)+d.required_count
    return render_template("institute/institute_sih_features.html", feature="demand_analytics", title="Industry Skill Demand Analytics",
                           demands=demands, domain_demand=sorted(by_domain.items(), key=lambda x:x[1], reverse=True))


@institute_bp.route("/internship-analytics")
def internship_analytics():
    progress=InternshipProgress.query.all()
    completion=InternshipCompletion.query.all()
    return render_template("institute/institute_sih_features.html", feature="internship_analytics", title="Advanced Internship Analytics",
                           active=sum(1 for x in progress if x.status in ["Started","In Progress"]),
                           completed=len(completion), total=len(progress), progress_rows=progress)


@institute_bp.route("/placement-analytics")
def placement_analytics():
    placements=Placement.query.all()
    return render_template("institute/institute_sih_features.html", feature="placement_analytics", title="Advanced Placement Analytics",
                           placements=placements, total=len(placements))


@institute_bp.route("/career-guidance")
def career_guidance():
    careers=CareerGuidance.query.order_by(CareerGuidance.domain).all()
    return render_template("institute/institute_sih_features.html", feature="career", title="Career Guidance", careers=careers)


@institute_bp.route("/workshops")
def workshops():
    return render_template("institute/institute_sih_features.html", feature="workshops", title="Industry Workshops",
                           workshops=IndustryWorkshop.query.order_by(IndustryWorkshop.workshop_date).all())


@institute_bp.route("/guest-lectures")
def guest_lectures():
    return render_template("institute/institute_sih_features.html", feature="lectures", title="Guest Lectures",
                           lectures=GuestLecture.query.order_by(GuestLecture.lecture_date).all())


@institute_bp.route("/live-projects")
def live_projects():
    return render_template("institute/institute_sih_features.html", feature="projects", title="Live Industry Projects",
                           projects=LiveIndustryProject.query.order_by(LiveIndustryProject.deadline).all())


@institute_bp.route("/research-collaboration")
def research_collaboration():
    return render_template("institute/institute_sih_features.html", feature="research", title="Research Collaboration",
                           projects=ResearchCollaboration.query.all())


@institute_bp.route("/advanced-reports")
def advanced_reports():
    return render_template("institute/institute_sih_features.html", feature="reports", title="Advanced Institute Reports",
                           report_names=[
                               "Industry Skill Demand Report","Skill Gap Report","Internship Completion Report",
                               "Mentor Feedback Report","Placement Readiness Report","Industry-wise Placement Report",
                               "Student Skill Report","Industry-wise Hiring Report"
                           ])


@institute_bp.route("/role-access")
def role_access():
    return render_template("institute/institute_sih_features.html", feature="roles", title="Role-Based Access",
                           roles=RolePermission.query.order_by(RolePermission.role).all())


@institute_bp.route("/documents", methods=["GET", "POST"])
def documents():
    upload_dir = Path(__file__).resolve().parent.parent / "uploads"
    upload_dir.mkdir(exist_ok=True)
    if request.method == "POST":
        student_id = request.form.get("student_id", type=int)
        file = request.files.get("document")
        if not student_id or not file or not file.filename:
            flash("Student and document file are required.", "warning")
            return redirect(url_for("institute.documents"))
        original = secure_filename(file.filename)
        stored = f"{uuid.uuid4().hex}_{original}"
        file.save(upload_dir / stored)
        db.session.add(SecureDocumentFile(student_id=student_id, document_name=original,
            stored_name=stored, document_type=request.form.get("document_type", "Academic")))
        db.session.commit()
        flash("Document uploaded securely and sent for verification.", "success")
        return redirect(url_for("institute.documents"))
    docs = SecureDocumentFile.query.order_by(SecureDocumentFile.id.desc()).all()
    legacy = SecureDocument.query.join(Student).order_by(SecureDocument.id.desc()).all()
    return render_template("institute/institute_extended.html", feature="documents", title="Secure Document Management",
                           documents=docs, legacy_documents=legacy, students=Student.query.order_by(Student.name).all())

@institute_bp.route("/documents/verify/<int:doc_id>", methods=["POST"])
def verify_document(doc_id):
    doc=SecureDocumentFile.query.get_or_404(doc_id)
    doc.verification_status=request.form.get("status","Verified")
    db.session.commit()
    flash("Document verification status updated.", "success")
    return redirect(url_for("institute.documents"))

@institute_bp.route("/documents/view/<int:doc_id>")
def view_document(doc_id):
    doc=SecureDocumentFile.query.get_or_404(doc_id)
    if doc.verification_status != "Verified":
        flash("Only verified documents can be securely viewed.", "warning")
        return redirect(url_for("institute.documents"))
    return send_from_directory(Path(__file__).resolve().parent.parent / "uploads", doc.stored_name, as_attachment=False)

@institute_bp.route("/documents/download/<int:doc_id>")
def download_document(doc_id):
    doc=SecureDocumentFile.query.get_or_404(doc_id)
    if doc.verification_status != "Verified":
        flash("Only verified documents can be downloaded.", "warning")
        return redirect(url_for("institute.documents"))
    return send_from_directory(Path(__file__).resolve().parent.parent / "uploads", doc.stored_name, as_attachment=True, download_name=doc.document_name)

@institute_bp.route("/industry-jobs", methods=["GET", "POST"])
def industry_jobs():
    if request.method=="POST":
        db.session.add(IndustryJob(title=request.form["title"], company=request.form["company"],
            required_degree=request.form.get("required_degree","BAMS"), required_skills=request.form.get("required_skills"),
            location=request.form.get("location"), package=request.form.get("package"),
            deadline=date.fromisoformat(request.form["deadline"]) if request.form.get("deadline") else None,
            description=request.form.get("description")))
        db.session.commit(); flash("Ayurveda industry job posted.","success"); return redirect(url_for("institute.industry_jobs"))
    return render_template("institute/institute_extended.html", feature="jobs", title="Industry Job Posting",
        jobs=IndustryJob.query.order_by(IndustryJob.id.desc()).all(), jobs_students=Student.query.order_by(Student.name).all())

@institute_bp.route("/recruitment", methods=["GET", "POST"])
def recruitment():
    if request.method=="POST":
        a=JobApplication.query.get_or_404(request.form.get("application_id",type=int))
        a.status=request.form.get("status", "Applied")
        a.interview_date=date.fromisoformat(request.form["interview_date"]) if request.form.get("interview_date") else None
        a.notes=request.form.get("notes")
        db.session.commit(); flash("Recruitment status updated.","success"); return redirect(url_for("institute.recruitment"))
    return render_template("institute/institute_extended.html", feature="recruitment", title="Job Recruitment & Placement",
        applications=JobApplication.query.order_by(JobApplication.id.desc()).all())

@institute_bp.route("/job-apply", methods=["POST"])
def job_apply():
    sid=request.form.get("student_id",type=int); jid=request.form.get("job_id",type=int)
    if sid and jid and not JobApplication.query.filter_by(student_id=sid,job_id=jid).first():
        db.session.add(JobApplication(student_id=sid,job_id=jid)); db.session.commit(); flash("Student application submitted.","success")
    return redirect(url_for("institute.industry_jobs"))

@institute_bp.route("/faculty-programs", methods=["GET", "POST"])
def faculty_programs():
    if request.method=="POST":
        db.session.add(FacultyProgram(faculty_name=request.form["faculty_name"],program_type=request.form["program_type"],
            organization=request.form.get("organization"),topic=request.form.get("topic"),
            start_date=date.fromisoformat(request.form["start_date"]) if request.form.get("start_date") else None,
            end_date=date.fromisoformat(request.form["end_date"]) if request.form.get("end_date") else None,
            status=request.form.get("status","Planned"),outcome=request.form.get("outcome")))
        db.session.commit(); flash("Faculty program added.","success"); return redirect(url_for("institute.faculty_programs"))
    return render_template("institute/institute_extended.html",feature="faculty",title="Academician & Faculty Programs",
        programs=FacultyProgram.query.order_by(FacultyProgram.id.desc()).all())

@institute_bp.route("/industry-training", methods=["GET", "POST"])
def industry_training():
    if request.method=="POST":
        db.session.add(IndustryTraining(title=request.form["title"],provider=request.form.get("provider"),skill=request.form.get("skill"),
            duration=request.form.get("duration"),certificate=request.form.get("certificate"),mentor=request.form.get("mentor"),
            seats=int(request.form.get("seats") or 0),progress=int(request.form.get("progress") or 0)))
        db.session.commit(); flash("Industry training program created.","success"); return redirect(url_for("institute.industry_training"))
    return render_template("institute/institute_extended.html",feature="industry_training",title="Industry Training & Certification",
        trainings=IndustryTraining.query.order_by(IndustryTraining.id.desc()).all(),participations=TrainingParticipation.query.order_by(TrainingParticipation.id.desc()).all(),students=Student.query.order_by(Student.name).all())

@institute_bp.route("/training-participation", methods=["POST"])
def training_participation():
    db.session.add(TrainingParticipation(student_id=int(request.form["student_id"]),training_id=int(request.form["training_id"]),
        progress=int(request.form.get("progress") or 0),status=request.form.get("status","Enrolled"),certificate_status=request.form.get("certificate_status","Pending")))
    db.session.commit(); flash("Student training participation saved.","success"); return redirect(url_for("institute.industry_training"))

@institute_bp.route("/notifications", methods=["GET", "POST"])
def notifications():
    if request.method=="POST":
        db.session.add(Notification(title=request.form["title"],message=request.form["message"],category=request.form.get("category","General"),audience=request.form.get("audience","Institute"),priority=request.form.get("priority","Normal")))
        db.session.commit(); flash("Notification published.","success"); return redirect(url_for("institute.notifications"))
    return render_template("institute/institute_extended.html",feature="notifications",title="Institute Notifications",notifications=Notification.query.order_by(Notification.id.desc()).all())

@institute_bp.route("/notifications/read/<int:notification_id>", methods=["POST"])
def notification_read(notification_id):
    n=Notification.query.get_or_404(notification_id); n.is_read=True; db.session.commit(); return redirect(url_for("institute.notifications"))

@institute_bp.route("/innovation-challenges", methods=["GET", "POST"])
def innovation_challenges():
    if request.method=="POST":
        db.session.add(InnovationChallenge(title=request.form["title"],industry=request.form.get("industry"),problem_statement=request.form.get("problem_statement"),skills=request.form.get("skills"),deadline=date.fromisoformat(request.form["deadline"]) if request.form.get("deadline") else None))
        db.session.commit(); flash("Innovation challenge created.","success"); return redirect(url_for("institute.innovation_challenges"))
    return render_template("institute/institute_extended.html",feature="challenges",title="Innovation Challenges",challenges=InnovationChallenge.query.order_by(InnovationChallenge.id.desc()).all(),submissions=ChallengeSubmission.query.order_by(ChallengeSubmission.id.desc()).all(),students=Student.query.order_by(Student.name).all())

@institute_bp.route("/challenge-submit", methods=["POST"])
def challenge_submit():
    db.session.add(ChallengeSubmission(challenge_id=int(request.form["challenge_id"]),student_id=int(request.form["student_id"]),team_name=request.form.get("team_name"),submission=request.form.get("submission")))
    db.session.commit(); flash("Challenge submission recorded.","success"); return redirect(url_for("institute.innovation_challenges"))

@institute_bp.route("/challenge-evaluate", methods=["POST"])
def challenge_evaluate():
    s=ChallengeSubmission.query.get_or_404(request.form.get("submission_id",type=int)); s.score=float(request.form.get("score") or 0); s.result=request.form.get("result","Evaluated"); db.session.commit(); flash("Innovation challenge evaluation saved.","success"); return redirect(url_for("institute.innovation_challenges"))
