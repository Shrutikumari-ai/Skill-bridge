from flask import Blueprint, render_template
from models import Student, Internship, AssessmentAttempt, AssessmentAnswer
from services import GapAnalyzer, get_learning_resources


roadmap_bp = Blueprint("roadmap", __name__)


@roadmap_bp.route("/roadmap/<int:student_id>/<int:internship_id>")
def show_roadmap(student_id, internship_id):

    student = Student.query.get_or_404(student_id)

    internship = Internship.query.get_or_404(
        internship_id
    )

    # Latest assessment
    attempt = (
        AssessmentAttempt.query
        .filter_by(
            student_id=student.id
        )
        .order_by(
            AssessmentAttempt.id.desc()
        )
        .first()
    )

    assessment_roadmap = []
    category_scores = {}

    # =====================================================
    # ASSESSMENT ANALYSIS
    # =====================================================

    if attempt:

        answers = (
            AssessmentAnswer.query
            .filter_by(
                attempt_id=attempt.id
            )
            .all()
        )

        category_stats = {}

        for answer in answers:

            question = answer.question

            if not question:
                continue

            category = question.category

            if category not in category_stats:

                category_stats[category] = {
                    "correct": 0,
                    "total": 0
                }

            category_stats[category]["total"] += 1

            if answer.is_correct:

                category_stats[category]["correct"] += 1

        # Calculate category scores
        for category, stats in category_stats.items():

            if stats["total"] > 0:

                score = round(
                    (
                        stats["correct"]
                        / stats["total"]
                    ) * 100,
                    2
                )

            else:

                score = 0

            category_scores[category] = score

        # Generate assessment roadmap
        assessment_roadmap = (
            GapAnalyzer.generate_assessment_roadmap(
                category_scores
            )
        )

        # Add learning resources
        for item in assessment_roadmap:

            if item.get("required") is None:
                item["required"] = 60

            if item.get("score") is None:
                item["score"] = 0

            if item.get("gap") is None:

                item["gap"] = max(
                    0,
                    item["required"]
                    - item["score"]
                )

            item["title"] = (
                item.get("skill", "")
                .replace("_", " ")
                .title()
            )

            item["resources"] = (
                get_learning_resources(
                    item.get("skill")
                )
            )

    # =====================================================
    # INTERNSHIP SKILL GAP
    # =====================================================

    internship_gap = GapAnalyzer.check_gap(
        student,
        internship
    )

    internship_roadmap = (
        GapAnalyzer.generate_roadmap(
            internship_gap
        )
    )

    # =====================================================
    # LEARNING RESOURCES FOR INTERNSHIP GAPS
    # =====================================================

    internship_learning = {}

    for skill in internship_gap:

        internship_learning[skill] = (
            get_learning_resources(skill)
        )

    # =====================================================
    # SEND DATA TO EXISTING UI
    # =====================================================

    return render_template(

        "roadmap.html",

        student=student,

        internship=internship,

        attempt=attempt,

        category_scores=category_scores,

        assessment_roadmap=assessment_roadmap,

        internship_gap=internship_gap,

        internship_roadmap=internship_roadmap,

        internship_learning=internship_learning
    )