from models import (
    Placement,
    AssessmentAttempt,
    AssessmentAnswer,
    AssessmentQuestion
)


# =========================================================
# SKILL MAPPER
# =========================================================

class SkillMapper:
    """
    Personalized opportunity matching.

    Matching factors:
    1. Student skills
    2. Desired career field
    3. Student location
    4. Assessment performance
    """

    # Assessment category -> practical skill
    CATEGORY_TO_SKILL = {
        "domain": "panchakarma",
        "clinical": "patient care",
        "pharmacy": "formulation",
        "research": "research",
        "public_health": "public health",
        "communication": "communication",
        "soft_skills": "soft skills"
    }

    @staticmethod
    def normalize(value):
        return (value or "").strip().lower()

    @staticmethod
    def get_student_assessment_skills(student):

        attempt = (
            AssessmentAttempt.query
            .filter_by(student_id=student.id)
            .order_by(AssessmentAttempt.id.desc())
            .first()
        )

        if not attempt:
            return set()

        answers = (
            AssessmentAnswer.query
            .filter_by(attempt_id=attempt.id)
            .all()
        )

        category_stats = {}

        for answer in answers:

            question = AssessmentQuestion.query.get(
                answer.question_id
            )

            if not question:
                continue

            category = question.category

            if category not in category_stats:
                category_stats[category] = {
                    "correct": 0,
                    "total": 0
                }

            category_stats[category]["total"] += 1

            if answer.is_correct:
                category_stats[category]["correct"] += 1

        assessment_skills = set()

        for category, stats in category_stats.items():

            if stats["total"] == 0:
                continue

            score = (
                stats["correct"]
                / stats["total"]
            ) * 100

            # 60%+ means skill is reasonably strong
            if score >= 60:

                skill = SkillMapper.CATEGORY_TO_SKILL.get(
                    category
                )

                if skill:
                    assessment_skills.add(
                        skill.lower()
                    )

        return assessment_skills

    @staticmethod
    def calculate_match(student, internship):

        student_skills = set(
            student.skill_list()
        )

        required_skills = set(
            internship.required_skill_list()
        )

        desired_field = SkillMapper.normalize(
            student.desired_field
        )

        internship_field = SkillMapper.normalize(
            internship.field
        )

        student_city = SkillMapper.normalize(
            student.city
        )

        student_state = SkillMapper.normalize(
            student.state
        )

        internship_city = SkillMapper.normalize(
            internship.city
        )

        internship_state = SkillMapper.normalize(
            internship.state
        )

        # -------------------------------------------------
        # 1. EXISTING SKILL MATCH
        # -------------------------------------------------

        if required_skills:

            matched_skills = (
                student_skills
                & required_skills
            )

            skill_match_percentage = round(
                (
                    len(matched_skills)
                    / len(required_skills)
                ) * 100,
                2
            )

        else:

            matched_skills = set()

            skill_match_percentage = 100

        # -------------------------------------------------
        # 2. ASSESSMENT SKILL MATCH
        # -------------------------------------------------

        assessment_skills = (
            SkillMapper.get_student_assessment_skills(
                student
            )
        )

        assessment_matches = (
            assessment_skills
            & required_skills
        )

        if required_skills:

            assessment_match_percentage = round(
                (
                    len(assessment_matches)
                    / len(required_skills)
                ) * 100,
                2
            )

        else:

            assessment_match_percentage = 100

        # -------------------------------------------------
        # 3. FIELD MATCH
        # -------------------------------------------------

        field_match = False

        if desired_field and internship_field:

            if (
                desired_field in internship_field
                or internship_field in desired_field
            ):
                field_match = True

        field_score = (
            100
            if field_match
            else 0
        )

        # -------------------------------------------------
        # 4. LOCATION MATCH
        # -------------------------------------------------

        location_match = False
        location_score = 0

        if (
            student_city
            and internship_city
            and student_city == internship_city
        ):

            location_match = True
            location_score = 100

        elif (
            student_state
            and internship_state
            and student_state == internship_state
        ):

            location_match = True
            location_score = 70

        elif (
            not internship_city
            and not internship_state
        ):

            location_match = True
            location_score = 40

        # -------------------------------------------------
        # 5. FINAL PERSONALIZED SCORE
        # -------------------------------------------------

        final_score = round(
            (
                skill_match_percentage * 0.40
                +
                assessment_match_percentage * 0.20
                +
                location_score * 0.25
                +
                field_score * 0.15
            ),
            2
        )

        # -------------------------------------------------
        # MISSING SKILLS
        # -------------------------------------------------

        missing_skills = sorted(
            required_skills
            - student_skills
            - assessment_skills
        )

        # Assessment weaknesses
        assessment_gaps = sorted(
            required_skills
            - assessment_skills
        )

        return {
            "match_percentage": final_score,

            "skill_match_percentage":
                skill_match_percentage,

            "assessment_match_percentage":
                assessment_match_percentage,

            "location_score":
                location_score,

            "field_score":
                field_score,

            "location_match":
                location_match,

            "field_match":
                field_match,

            "matched_skills":
                sorted(matched_skills),

            "assessment_matches":
                sorted(assessment_matches),

            "missing_skills":
                missing_skills,

            "assessment_gaps":
                assessment_gaps
        }

    @staticmethod
    def find_matches(student, internships):

        matches = []

        for internship in internships:

            result = SkillMapper.calculate_match(
                student,
                internship
            )

            # Opportunity tab mein relevant
            # opportunities show hongi.
            #
            # Completely unrelated opportunity ko
            # remove karne ke liye minimum condition.

            if (
                result["match_percentage"] >= 20
                or result["field_match"]
                or result["location_match"]
                or result["matched_skills"]
                or result["assessment_matches"]
            ):

                matches.append({
                    "internship":
                        internship,

                    **result
                })

        matches.sort(
            key=lambda x: x["match_percentage"],
            reverse=True
        )

        return matches


# =========================================================
# GAP ANALYZER
# =========================================================

class GapAnalyzer:

    """
    Finds missing skills and creates personalized
    learning roadmaps.
    """

    ROADMAP_RESOURCES = {

        "panchakarma":
            "AYUSH portal Panchakarma certification resources",

        "patient care":
            "Clinical patient-care and healthcare communication resources",

        "research":
            "Research methodology and scientific research resources",

        "formulation":
            "Ayurvedic pharmacy and formulation resources",

        "communication":
            "Professional and healthcare communication resources",

        "public health":
            "Public health and community-health resources",

        "marketing":
            "Digital marketing and healthcare marketing resources",

        "soft skills":
            "Professional workplace and soft-skills resources"
    }

    # -----------------------------------------------------
    # INTERNSHIP GAP
    # -----------------------------------------------------

    @staticmethod
    def check_gap(student, internship):

        student_skills = set(
            student.skill_list()
        )

        required_skills = set(
            internship.required_skill_list()
        )

        return sorted(
            required_skills
            - student_skills
        )

    # -----------------------------------------------------
    # OLD ROADMAP
    # -----------------------------------------------------

    @staticmethod
    def generate_roadmap(gap):

        return {

            skill:
                GapAnalyzer.ROADMAP_RESOURCES.get(
                    skill,
                    f"Search Coursera/YouTube for '{skill}' courses"
                )

            for skill in gap
        }

    # -----------------------------------------------------
    # ASSESSMENT → SKILL MAPPING
    # -----------------------------------------------------

    @staticmethod
    def generate_assessment_roadmap(
        category_scores,
        threshold=60
    ):

        category_to_skill = {

            "domain":
                "panchakarma",

            "clinical":
                "patient care",

            "pharmacy":
                "formulation",

            "research":
                "research",

            "public_health":
                "public health",

            "communication":
                "communication",

            "soft_skills":
                "soft skills"
        }

        roadmap = []

        for category, score in category_scores.items():

            if score < threshold:

                skill = category_to_skill.get(
                    category,
                    category
                )

                roadmap.append({

                    "category":
                        category,

                    "skill":
                        skill,

                    "score":
                        round(score, 2),

                    "gap":
                        round(
                            threshold - score,
                            2
                        ),

                    "required":
                        threshold,

                    "title":
                        skill.title()
                })

        # Weakest skill first
        roadmap.sort(
            key=lambda x: x["score"]
        )

        return roadmap


# =========================================================
# PLACEMENT MANAGER
# =========================================================

class PlacementManager:

    """
    Handles company collaboration
    and placement records.
    """

    @staticmethod
    def create_placement(
        db,
        student,
        company,
        internship=None
    ):

        placement = Placement(

            student_id=
                student.id,

            company_id=
                company.id,

            internship_id=(
                internship.id
                if internship
                else None
            ),

            status=
                "placed"
        )

        db.session.add(
            placement
        )

        db.session.commit()

        return placement


# =========================================================
# AUTOMATED FRAMEWORK
# =========================================================

class AutomatedFramework:

    """
    Full automation pipeline:

    Student
       ↓
    Profile
       ↓
    Assessment
       ↓
    Skills
       ↓
    Location
       ↓
    Internship Match
       ↓
    Skill Gap
       ↓
    Eligibility
       ↓
    Roadmap
    """

    @staticmethod
    def process_student(
        student,
        internships
    ):

        matches = SkillMapper.find_matches(
            student,
            internships
        )

        results = []

        for match in matches:

            internship = match["internship"]

            gap = GapAnalyzer.check_gap(
                student,
                internship
            )

            # Assessment score
            latest_attempt = (
                AssessmentAttempt.query
                .filter_by(
                    student_id=student.id
                )
                .order_by(
                    AssessmentAttempt.id.desc()
                )
                .first()
            )

            assessment_score = 0

            if latest_attempt:

                assessment_score = (
                    latest_attempt.score_percentage
                    or 0
                )

            # Eligibility
            #
            # Strong match + no missing skills
            # = eligible
            #
            # Otherwise roadmap required.

            eligible = (
                len(gap) == 0
                and assessment_score >= 60
            )

            result = {

                "internship":
                    internship,

                "eligible":
                    eligible,

                "gap":
                    gap,

                "roadmap":
                    GapAnalyzer.generate_roadmap(
                        gap
                    ),

                "match_percentage":
                    match["match_percentage"],

                "skill_match_percentage":
                    match["skill_match_percentage"],

                "assessment_match_percentage":
                    match[
                        "assessment_match_percentage"
                    ],

                "location_match":
                    match["location_match"],

                "field_match":
                    match["field_match"],

                "matched_skills":
                    match["matched_skills"],

                "assessment_matches":
                    match["assessment_matches"],

                "missing_skills":
                    match["missing_skills"],

                "assessment_gaps":
                    match["assessment_gaps"],

                "assessment_score":
                    assessment_score
            }

            results.append(
                result
            )

        results.sort(
            key=lambda x:
                x["match_percentage"],
            reverse=True
        )

        return results


# =========================================================
# LEARNING RESOURCES
# =========================================================

LEARNING_RESOURCES = {

    "panchakarma": {

        "description":
            "Learn the fundamentals of Panchakarma, Ayurvedic cleansing procedures and their basic clinical context.",

        "videos": [

            {
                "title":
                    "Panchakarma Basics",

                "description":
                    "Demo video search for understanding Panchakarma fundamentals.",

                "url":
                    "https://www.youtube.com/results?search_query=Panchakarma+Ayurveda+basics"
            },

            {
                "title":
                    "Introduction to Panchakarma",

                "description":
                    "Demo video search for introductory Panchakarma concepts.",

                "url":
                    "https://www.youtube.com/results?search_query=introduction+to+panchakarma"
            }
        ],

        "courses": [

            {
                "title":
                    "Ayurveda Courses",

                "description":
                    "Explore available Ayurveda-related learning opportunities.",

                "url":
                    "https://www.coursera.org/search?query=ayurveda"
            }
        ],

        "resources": [

            {
                "title":
                    "Ministry of Ayush",

                "description":
                    "Official Government of India AYUSH information portal.",

                "url":
                    "https://ayush.gov.in/"
            }
        ]
    },

    "patient care": {

        "description":
            "Improve basic patient-care knowledge, professional behaviour and healthcare interaction skills.",

        "videos": [

            {
                "title":
                    "Basic Patient Care",

                "description":
                    "Demo video search for basic patient-care concepts.",

                "url":
                    "https://www.youtube.com/results?search_query=basic+patient+care+skills"
            },

            {
                "title":
                    "Healthcare Communication",

                "description":
                    "Demo video search for communicating effectively with patients.",

                "url":
                    "https://www.youtube.com/results?search_query=healthcare+communication+skills"
            }
        ],

        "courses": [

            {
                "title":
                    "Patient Care Learning",

                "description":
                    "Explore patient-care related courses.",

                "url":
                    "https://www.coursera.org/search?query=patient%20care"
            }
        ],

        "resources": [

            {
                "title":
                    "WHO Health Topics",

                "description":
                    "Official WHO health information and educational resources.",

                "url":
                    "https://www.who.int/health-topics"
            }
        ]
    },

    "formulation": {

        "description":
            "Build knowledge of Ayurvedic formulations, pharmaceutical concepts and basic formulation principles.",

        "videos": [

            {
                "title":
                    "Ayurvedic Formulation Basics",

                "description":
                    "Demo video search for Ayurvedic formulation fundamentals.",

                "url":
                    "https://www.youtube.com/results?search_query=Ayurvedic+formulation+basics"
            },

            {
                "title":
                    "Ayurvedic Pharmacy",

                "description":
                    "Demo video search for Ayurvedic pharmacy concepts.",

                "url":
                    "https://www.youtube.com/results?search_query=Ayurvedic+pharmacy+basics"
            }
        ],

        "courses": [

            {
                "title":
                    "Ayurveda Learning Courses",

                "description":
                    "Explore Ayurveda-related courses and learning material.",

                "url":
                    "https://www.coursera.org/search?query=ayurveda"
            }
        ],

        "resources": [

            {
                "title":
                    "Ministry of Ayush",

                "description":
                    "Official AYUSH information and resources.",

                "url":
                    "https://ayush.gov.in/"
            }
        ]
    },

    "research": {

        "description":
            "Learn research methodology, scientific literature reading, evidence-based thinking and basic research practices.",

        "videos": [

            {
                "title":
                    "Research Methodology Basics",

                "description":
                    "Demo video search covering fundamentals of research methodology.",

                "url":
                    "https://www.youtube.com/results?search_query=research+methodology+basics"
            },

            {
                "title":
                    "How to Read Research Papers",

                "description":
                    "Demo video search for understanding scientific research papers.",

                "url":
                    "https://www.youtube.com/results?search_query=how+to+read+research+papers"
            }
        ],

        "courses": [

            {
                "title":
                    "Research Methodology Courses",

                "description":
                    "Explore research methodology courses.",

                "url":
                    "https://www.coursera.org/search?query=research%20methodology"
            }
        ],

        "resources": [

            {
                "title":
                    "PubMed",

                "description":
                    "Biomedical literature database for finding research papers.",

                "url":
                    "https://pubmed.ncbi.nlm.nih.gov/"
            }
        ]
    },

    "public health": {

        "description":
            "Develop understanding of public health, community health, prevention and population-level healthcare.",

        "videos": [

            {
                "title":
                    "Public Health Basics",

                "description":
                    "Demo video search for public-health fundamentals.",

                "url":
                    "https://www.youtube.com/results?search_query=public+health+basics"
            },

            {
                "title":
                    "Community Health",

                "description":
                    "Demo video search for community-health concepts.",

                "url":
                    "https://www.youtube.com/results?search_query=community+health+basics"
            }
        ],

        "courses": [

            {
                "title":
                    "Public Health Courses",

                "description":
                    "Explore public-health courses.",

                "url":
                    "https://www.coursera.org/search?query=public%20health"
            }
        ],

        "resources": [

            {
                "title":
                    "WHO",

                "description":
                    "Official World Health Organization health information.",

                "url":
                    "https://www.who.int/"
            },

            {
                "title":
                    "Ministry of Ayush",

                "description":
                    "Official AYUSH information and initiatives.",

                "url":
                    "https://ayush.gov.in/"
            }
        ]
    },

    "communication": {

        "description":
            "Improve professional communication, healthcare interaction, listening and presentation skills.",

        "videos": [

            {
                "title":
                    "Professional Communication",

                "description":
                    "Demo video search for professional communication skills.",

                "url":
                    "https://www.youtube.com/results?search_query=professional+communication+skills"
            },

            {
                "title":
                    "Healthcare Communication",

                "description":
                    "Demo video search for healthcare communication.",

                "url":
                    "https://www.youtube.com/results?search_query=healthcare+communication+skills"
            }
        ],

        "courses": [

            {
                "title":
                    "Communication Skills",

                "description":
                    "Explore communication-skills courses.",

                "url":
                    "https://www.coursera.org/search?query=communication%20skills"
            }
        ],

        "resources": [

            {
                "title":
                    "Coursera Learning",

                "description":
                    "Explore additional professional communication resources.",

                "url":
                    "https://www.coursera.org/search?query=professional%20communication"
            }
        ]
    },

    "soft skills": {

        "description":
            "Develop teamwork, leadership, problem-solving, workplace behaviour and other professional skills.",

        "videos": [

            {
                "title":
                    "Workplace Soft Skills",

                "description":
                    "Demo video search for workplace soft skills.",

                "url":
                    "https://www.youtube.com/results?search_query=workplace+soft+skills"
            },

            {
                "title":
                    "Teamwork and Leadership",

                "description":
                    "Demo video search for teamwork and leadership skills.",

                "url":
                    "https://www.youtube.com/results?search_query=teamwork+leadership+skills"
            }
        ],

        "courses": [

            {
                "title":
                    "Soft Skills Courses",

                "description":
                    "Explore soft-skills and workplace courses.",

                "url":
                    "https://www.coursera.org/search?query=soft%20skills"
            }
        ],

        "resources": [

            {
                "title":
                    "SWAYAM",

                "description":
                    "Government of India online learning platform.",

                "url":
                    "https://swayam.gov.in/"
            }
        ]
    }
}


# =========================================================
# RESOURCE GETTER
# =========================================================

def get_learning_resources(skill):

    skill_key = (
        skill or ""
    ).strip().lower()

    return LEARNING_RESOURCES.get(

        skill_key,

        {

            "description":
                f"Recommended learning resources for {skill}.",

            "videos":
                [],

            "courses":
                [],

            "resources":
                []
        }
    )